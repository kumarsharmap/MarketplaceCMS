import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormArray,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ParentSubscriptionComponent } from 'src/app/core/components/parent-subscription/parent-subscription.component';
import { RoleModel } from 'src/app/core/models/roles.model';
import {
  UserManagementModel,
  UserManagementTenantModel,
} from 'src/app/core/models/user-management.model';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
import { RoleService } from '../../services/role/role.service';
import { UserManagementService } from '../../services/user-management/user-management.service';

@Component({
  selector: 'app-manage-user-management',
  templateUrl: './manage-user-management.component.html',
  styleUrls: ['./manage-user-management.component.css'],
})
export class ManageUserManagementComponent
  extends ParentSubscriptionComponent
  implements OnInit {
  userManagement: UserManagementModel;
  roles: RoleModel[] = [];
  addUsers: UserManagementTenantModel[] = [];
  rolesValue: RoleModel;
  userManagementForm: FormGroup;

  constructor(
    private roleService: RoleService,
    private userManagementService: UserManagementService,
    private router: Router,
    private fb: FormBuilder,
    private toastNotificationService: ToastNotificationService
  ) {
    super();
  }

  ngOnInit(): void {
    this.getRoles();
    this.createTenant();
    this.userManagement = this.userManagementService.getManageUser();
    if (this.userManagement) {
      this.userManagementForm.patchValue({
        email: this.userManagement.email,
        name: this.userManagement.name,
      });
      this.addUsers = this.userManagement.tenantUser;
    }
    this.populateUsersTable();
  }

  public onUserManagement(): void {
    this.subscriptions.push(
      this.userManagementService
        .updateUserManagement(
          this.userManagement.userId,
          this.userManagementForm.value
        )
        .subscribe(
          () => {
            this.toastNotificationService.showSuccess(
              'User Update Successfully'
            );
            this.router.navigate(['/user']);
          },
          (error: HttpErrorResponse) => {
            throw new Error(error.error.message);
          }
        )
    );
  }

  get userManagementArray(): FormArray {
    if (this.userManagementForm) {
      return this.userManagementForm.get('tenantUser') as FormArray;
    }
  }

  public onSelectedRole(event: Event, i: number): void {
    const value = (event.target as HTMLInputElement).value;
    this.rolesValue = this.roles.find((data) => data.roleName === value);
    this.addUsers[i].roleId = this.rolesValue.roleId;
    this.addUsers[i].roleName = this.rolesValue.roleName;
    this.populateUsersTable();
  }

  private populateUsersTable(): void {
    this.userManagementArray.controls = [];
    if (this.addUsers.length > 0) {
      this.addUsers.forEach((user) => {
        this.userManagementArray.push(
          this.fb.group({
            roleId: this.fb.control(user.roleId),
            roleName: this.fb.control(user.roleName),
            tenantId: this.fb.control(user.tenantId),
          })
        );
      });
    }
  }

  public addTenant(addUser: any): void {
    this.userManagementArray.clear();
    this.addUsers.push(addUser);
    this.populateUsersTable();
  }

  public onDeleteUser(user) {
    const userIndex = user.controls.tenantId.value;
    this.addUsers = this.addUsers.filter((item) => {
      return item.tenantId !== userIndex;
    });
    this.userManagementArray.clear();
    this.populateUsersTable();
  }

  public onDeleteUserManagement() {
    this.userManagementService
      .deleteUserManagement(this.userManagement.userId)
      .subscribe((deleteResponse) => {
        this.router.navigate(['/user']);
      });
  }

  private createTenant(): void {
    this.userManagementForm = new FormGroup({
      email: new FormControl('', Validators.required),
      name: new FormControl('', Validators.required),
      tenantUser: new FormArray([]),
    });
  }

  private getRoles(): void {
    this.roleService.getRole().subscribe((role) => {
      this.roles = role;
    });
  }
}
