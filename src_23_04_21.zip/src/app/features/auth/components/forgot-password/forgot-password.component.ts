import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { ParentSubscriptionComponent } from 'src/app/core/components/parent-subscription/parent-subscription.component';
import { LoginService } from '../../services/login/login.service';
import { RegisterService } from '../../services/regsiter/register.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
})
export class ForgotPasswordComponent
  extends ParentSubscriptionComponent
  implements OnInit {
  forgotPasswordForm: FormGroup;

  constructor(
    private router: Router,
    private registerService: RegisterService,
    private loginService: LoginService
  ) {
    super();
  }

  ngOnInit(): void {
    this.forgotPasswordForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
    });
  }

  onForgot(): void {
    this.subscriptions.push(
      this.registerService
        .forgotPassword(this.forgotPasswordForm.value)
        .pipe(take(1))
        .subscribe(
          () => {
            this.router.navigate(['/forgotpassword']);
            this.loginService.authentication$.next(null);
          },
          (error: HttpErrorResponse) => {
            throw new Error(error.error.message);
          }
        )
    );
  }
}
