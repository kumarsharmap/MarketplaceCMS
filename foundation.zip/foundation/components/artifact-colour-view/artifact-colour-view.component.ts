import { Component, Input, OnInit } from '@angular/core';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
import { FoundationService } from '../services/foundation.service';

@Component({
  selector: 'app-artifact-colour-view',
  templateUrl: './artifact-colour-view.component.html',
  styleUrls: ['./artifact-colour-view.component.css']
})
export class ArtifactColourViewComponent implements OnInit {
  listOfFoundationArtifacts: string[];
  coloursDetails: any;
  @Input('data') id: string;
  constructor(public foundationServ: FoundationService, private toastNotificationService: ToastNotificationService) { }

  ngOnInit() {
    console.log("view", this.id);
    //Need to remove after integration
    this.coloursDetails = {
      "pageTitle": {
        "label": "Page Title",
        "value": "Colours",
        "type": "text"
      },
      "pageDescription": {
        "label": "Page Description",
        "value": "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences",
        "type": "text"
      },
      "colorSection": [
        {
          "description": "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences",
          "items": [{
            "colourName": "Blue",
            "hexaValue": "#0000FF",
            "rgbValue": "(0, 0, 255)"
          }],
          "title": "Primary Colours"
        },
        {
          "description": "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences",
          "items": [{
            "colourName": "Orange",
            "hexaValue": "#FF6600",
            "rgbValue": "(255, 102, 0)"
          },
          {
            "colourName": "White",
            "hexaValue": "#FFFFFF",
            "rgbValue": "255,255,255"
          },
          {
            "colourName": "Orange",
            "hexaValue": "#FF66FF",
            "rgbValue": "(255, 102, 0)"
          },
          {
            "colourName": "White",
            "hexaValue": "#FFFFFF",
            "rgbValue": "255,255,255"
          },
          {
            "colourName": "Orange",
            "hexaValue": "#FF0000",
            "rgbValue": "(255, 102, 0)"
          },
          {
            "colourName": "White",
            "hexaValue": "#00FFFF",
            "rgbValue": "255,255,255"
          }
          ],
          "title": "Secondary Colours"
        }
      ]
    }

    this.foundationServ.fetchDetailsById(this.id).subscribe(
      response => {
        console.log("API success");
        this.coloursDetails = response;
      },
      (error) => {
        this.toastNotificationService.showError("Fail to fetch details");
      })
  }

}
