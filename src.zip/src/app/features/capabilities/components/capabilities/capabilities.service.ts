import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
//import { map } from 'rxjs/operators';

import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { WebService } from 'src/app/core/services/web.service';

@Injectable({
  providedIn: 'root'
})
export class CapabilitiesService {

  private makerActionUrl;
  private approverActionUrl;
  private deleteRecordUrl;
  private allCapabilitiesUrl;
  private capabilityByIDUrl;
  private approverUpdateUrl;
  private makerUpdateUrl;


  makersubmit = '';
  makerupdate='';
  adminApprove = '';
  adminUpdate = '';
  delete = '';
  allCapabilities='';
  capabilityId='';

  constructor(private webService: WebService, private http: HttpClient) {
   
    this.makerActionUrl = environment.apiEndpoint + this.makersubmit;
    this.makerUpdateUrl = environment.apiEndpoint + this.makerupdate;
    this.approverActionUrl = environment.apiEndpoint + this.adminApprove;
    this.approverUpdateUrl = environment.apiEndpoint + this.adminUpdate;
    this.deleteRecordUrl = environment.apiEndpoint + this.delete;
    this.allCapabilitiesUrl = environment.apiEndpoint + this.allCapabilities;
    this.capabilityByIDUrl = environment.apiEndpoint + this.capabilityId;
   
  }
  makerAction(data, http?): Observable<any> {
    return this.webService.postRequest(this.makerActionUrl, data, http);
  }
  approverAction(data, http?): Observable<any> {
    return this.webService.postRequest(this.approverActionUrl, data, http);
  }
  approverUpdate(data): Observable<any> {
    return this.webService.putRequest(this.approverUpdateUrl, data);
  }
  makerUpdateAction(data): Observable<any> {
    return this.webService.putRequest(this.makerUpdateUrl, data);
  }
  deleteRecord(id): Observable<any> {
    return this.webService.deleteRequest(this.deleteRecordUrl + id);
  }
  
  getAllCapabilities(data, http?): Observable<any> {

    return this.webService.getRequest(this.allCapabilitiesUrl + data, http);
  }

  getCapabilityByID(id, http?): Observable<any> {
    return this.webService.getRequest(this.capabilityByIDUrl + id, http);
  }

}
