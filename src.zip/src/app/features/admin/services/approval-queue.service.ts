import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginResponse } from 'src/app/core/models/header-menu.model';
import { CreateTenantModel } from 'src/app/core/models/tenant.model';
import { HttpClientHelper } from 'src/http-client-helper';

@Injectable({
  providedIn: 'root',
})
export class ApprovalQueueService {
  selectTenant: LoginResponse;
  artifactName: string;
  tenant: CreateTenantModel[];

  constructor(private http: HttpClient) {}

  // public getuserId(userId: number): Observable<any> {
  //   return this.http.get(`${HttpClientHelper.APPROVALQUEUE}/${userId}`);
  // }

  public getuserId(userId): Observable<any> {
    return this.http.get(`${HttpClientHelper.APPROVALQUEUE}`);
  }

  public getTenantByUserId(userId): Observable<any> {
    return this.http.get(`${HttpClientHelper.TENANTSByADMIN}/${userId}`);
  }

  public setSelectTenant(selectTenant: LoginResponse): void {
    this.selectTenant = selectTenant;
  }

  public getSelectTenant(): LoginResponse {
    return this.selectTenant;
  }

  public setTenant(
    artifactName: string,
    selectTenant: CreateTenantModel[]
  ): void {
    this.tenant = selectTenant;
    this.artifactName = artifactName;
  }

  public geTenant(): CreateTenantModel[] {
    return this.tenant;
  }

  public getArtifactName(): string {
    return this.artifactName;
  }
}
