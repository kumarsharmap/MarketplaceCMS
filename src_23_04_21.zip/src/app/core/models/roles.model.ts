export class RoleModel {
  roleId: number;
  roleName: string;
  roleDescription: string;
  rolePermission: RolePermission[];
}

export class RolePermission {
  permissionId: number;
  permissionName: string;
}
