import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateFoundationComponent } from './create-foundation.component';

describe('CreateFoundationComponent', () => {
  let component: CreateFoundationComponent;
  let fixture: ComponentFixture<CreateFoundationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateFoundationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateFoundationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
