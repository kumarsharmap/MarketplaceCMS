import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { PermissionModel } from 'src/app/core/models/permission.model';
import { PermissionService } from '../../services/permissoin/permission.service';

@Component({
  selector: 'app-add-permission',
  templateUrl: './add-permission.component.html',
  styleUrls: ['./add-permission.component.css'],
})
export class AddPermissionComponent implements OnInit {
  @ViewChild('template') public templateref: TemplateRef<PermissionModel>;
  @Output()
  getPermissionDataFromChild: EventEmitter<PermissionModel> = new EventEmitter();
  permissionForm: FormGroup;
  modalRef: BsModalRef;
  isEditMode: boolean;

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private permissionService: PermissionService
  ) {}

  ngOnInit(): void {
    this.isEditMode = true;
    this.createPermissionForm();
  }

  public openModal(): void {
    this.isEditMode = true;
    this.modalRef = this.modalService.show(this.templateref);
  }

  public openPermissionModalEdit(permission: PermissionModel): void {
    this.isEditMode = false;
    this.permissionForm.patchValue(permission);
    this.modalRef = this.modalService.show(this.templateref);
  }

  public onSavePermissions(): void {
    const data = this.permissionForm.value;
    this.permissionService.addPermission(data).subscribe((permission: any) => {
      if (permission) {
        this.resetForm();
        this.getPermissionDataFromChild.emit();
      }
    });
  }

  public onUpdatePermissions(): void {
    const data = this.permissionForm.value;
    this.permissionService
      .updatePermission(data.permissionId, data)
      .subscribe((updatePermission) => {
        if (updatePermission) {
          this.resetForm();
          this.getPermissionDataFromChild.emit();
        }
      });
  }

  public onClose(): void {
    this.resetForm();
  }

  private resetForm(): void {
    this.modalRef.hide();
    this.permissionForm.reset();
  }

  private createPermissionForm(): void {
    this.permissionForm = this.fb.group({
      permissionId: '',
      permissionName: '',
      permissionDescription: '',
    });
  }
}
