import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormArray } from '@angular/forms';
import { MenuService } from 'src/app/core/services/menu/menu.service';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { capabilitiesData } from '../capabilities/capabilities.model';
import { TabDirective, TabsetComponent } from "ngx-bootstrap/tabs";
import { Subject } from 'rxjs';
import { CapabilitiesService } from './capabilities.service';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-capabilities',
  templateUrl: './capabilities.component.html',
  styleUrls: ['./capabilities.component.css'],
})
export class CapabilitiesComponent implements OnInit {
  @ViewChild("tabset") tabset: TabsetComponent;

  forms = new FormGroup({});
  form2 = new FormGroup({});
  form3 = new FormGroup({});
  options= [
               { label: "HTML", value: "html" },
               { label: "JS", value: "js" }
             ]
 myobj1 = capabilitiesData.examplesDTO[0].previews[0];
 myobj11 = capabilitiesData.examplesDTO[0].richTextBlock[0];
 myobj2= capabilitiesData.resourcesDTO[0];
 myObj3 = capabilitiesData.updatesDTO[0];
 headings=[];
 tabHeading: string = "Technical Summary";
 description="";
 pageTitle="";
 showForm:boolean=false;
 private onDestroy$: Subject<void>;
  capabilitiesArray: any;

  constructor(private capabilityService:CapabilitiesService) { 
    this.headings=[
    {tabTitle:"Technical Summary"},
    {tabTitle:"Resources"},
    {tabTitle:"Updates"}
  ]
  this.onDestroy$ = new Subject<void>();
  }

  confirmTabSwitch(data: TabDirective): void {
    this.tabHeading = data.heading;
    console.log(this.tabHeading);
  }

  showCapabilitiesForm(){
    this.showForm = true;
    console.log(this.showForm);
  }
  ngOnInit(): void {
    this.forms = new FormGroup({
      previews: new FormArray([this.populatePreviewsArray()]),
      richTextBlock: new FormArray([this.populateRichTextArray()]),

    });
     this.form2 = new FormGroup({
      resources: new FormArray([this.populateResourcesArray()]),
     

    });
     this.form3 = new FormGroup({
       updates: new FormArray([this.populateUpdatesArray()]),

    });
    console.log(this.forms);
  }
  populatePreviewsArray(): FormGroup {
    return new FormGroup({
      blockTitle: new FormControl(""),
      summdescription: new FormControl(""),
      previewImages: new FormArray([this.populatePreviwImagesArray()]),
      codeSection: new FormArray([this.populateCodeSectionArray()]),
    });
  }

  populatePreviwImagesArray(): FormGroup{
  return new FormGroup({
     previewImage: new FormControl("")
    });
  }

  populateCodeSectionArray(): FormGroup{
     return new FormGroup({
     syntax: new FormControl(""),
     code: new FormControl("")
    });
  }
  populateRichTextArray(): FormGroup{
     return new FormGroup({
     blockTitle: new FormControl(""),
     richText: new FormControl("")
    });
  }
populateResourcesArray(): FormGroup{
   return new FormGroup({
      resourceName: new FormControl(""),
      linkLocation: new FormControl(""),
     });
}
populateUpdatesArray(): FormGroup{
   return new FormGroup({
      dateOfUpdate: new FormControl(""),
      version: new FormControl(""),
      updateDescription: new FormControl(""),
     });
}
  // get examples() {
  //   return (this.forms.get("previews") as FormArray).controls;
  // }
   examples(): FormArray {
    return this.forms.get("previews") as FormArray
  }
   images(index:number) : FormArray {
    return this.examples().at(index).get("previewImages") as FormArray
  }
    codes(index:number) : FormArray {
    return this.examples().at(index).get("codeSection") as FormArray
  }
  richTxt(): FormArray {
    return this.forms.get("richTextBlock") as FormArray
  }
  resource(): FormArray {
    return this.form2.get("resources") as FormArray
  }
   update(): FormArray {
    return this.form3.get("updates") as FormArray
  }



  addPreviews() {
    let control = this.forms.get("previews") as FormArray;
    control.push(this.populatePreviewsArray());
  }
  addRichText() {
    let control = this.forms.get("richTextBlock") as FormArray;
    control.push(this.populateRichTextArray());
  }
   addCode(i) {
    let control = this.examples().at(i).get("codeSection") as FormArray;
    control.push(this.populateCodeSectionArray());
  }
  addResources() {
    let control = this.form2.get("resources") as FormArray;
    control.push(this.populateResourcesArray());
  }
  addUpdates() {
    let control = this.form3.get("updates") as FormArray;
    control.push(this.populateUpdatesArray());
  }

  removePreviews(i) {
    let control = this.forms.get("previews") as FormArray;
    control.removeAt(i);
  }
   removeCode(i) {
    let control =  this.examples().at(i).get("codeSection") as FormArray;
    control.removeAt(i);
  }
  removeRichText(i){
    let control = this.forms.get("richTextBlock") as FormArray;
    control.removeAt(i);
  }
   removeResources(i){
    let control = this.form2.get("resources") as FormArray;
    control.removeAt(i);
  }
   removeUpdates(i){
    let control = this.form3.get("updates") as FormArray;
    control.removeAt(i);
  }

  getCapabilities() {
    let data=''
    this.capabilityService.getAllCapabilities(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.capabilitiesArray = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  getByID() {
    let data=''
    this.capabilityService.getCapabilityByID(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.capabilitiesArray = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  makerAction(btnAction){
if(btnAction == 'save'){

}
else if(btnAction == 'submit'){

}
let model = {
  pagetitle: {
    label: "Page Title",
    value: this.pageTitle,
    type: "text"
  },
  description: {
    label: "Description",
    value: this.description,
    type: "text"
  },
  userDetails: {
    userName:"test",
    artifactId:"test"
  },

  examplesDTO: [],
  resourcesDTO: [],
  updatesDTO: []

};
 
  model['examplesDTO'] = [this.examplesFormToModel()];
  model['resourcesDTO'] = [this.resourcesFormToModel()];
  model['updatesDTO'] = [this.updatesFormToModel()];


  }

  examplesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.examplesDTO[0]);
    let formData = this.forms.getRawValue();
      for (let key in formData) {
      if (modelData.hasOwnProperty(key))
        modelData[key] = formData[key] || '';
    };
   console.log("modelData",modelData);
    return modelData;
  };

  resourcesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.resourcesDTO[0]);
    let formData = this.form2.getRawValue();
      for (let key in formData) {
      if (modelData.hasOwnProperty(key))
        modelData[key] = formData[key] || '';
    };
   console.log("modelData",modelData);
    return modelData;
  };

  updatesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.updatesDTO[0]);
    let formData = this.form3.getRawValue();
      for (let key in formData) {
      if (modelData.hasOwnProperty(key))
        modelData[key] = formData[key] || '';
    };
   console.log("modelData",modelData);
    return modelData;
  };
  
  onFileChane(event){
    this.images(0).patchValue(event.target.value);
  }

  onSubmit() {
    console.log(this.forms.value);
     console.log(this.form2.value);
      console.log(this.form3.value);
  }

  public ngOnDestroy(): void {
    this.onDestroy$.next();
    this.onDestroy$.complete();

  }
  
}
