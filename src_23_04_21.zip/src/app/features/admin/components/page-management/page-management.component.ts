import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginResponse } from 'src/app/core/models/header-menu.model';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { ApprovalQueueService } from '../../services/approval-queue.service';

@Component({
  selector: 'app-page-management',
  templateUrl: './page-management.component.html',
  styleUrls: ['./page-management.component.css'],
})
export class PageManagementComponent implements OnInit {
  pageManagement: LoginResponse[];

  constructor(
    private loginService: LoginService,
    private approvalQueueService: ApprovalQueueService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getuserId();
  }

  getuserId() {
    this.loginService.authentication$.subscribe(
      (loginResponse: LoginResponse[]) => {
        this.pageManagement = loginResponse;
      }
    );
  }

  onArtifactName(pagemanagement) {
    this.approvalQueueService.setSelectTenant(pagemanagement);
    this.router.navigate(['selecttenant']);
  }
}
