import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { capabilitiesData } from '../capabilities/capabilities.model';

@Component({
  selector: 'app-capabilities-updates',
  templateUrl: './capabilities-updates.component.html',
  styleUrls: ['./capabilities-updates.component.css']
})
export class CapabilitiesUpdatesComponent implements OnInit {
  updatesForm:FormGroup;
  showUpdatesAddBlock: boolean=true;
  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
    this.updatesForm=this.fb.group({
      updates: new FormArray([this.populateUpdatesArray()]),
    })
  }

  populateUpdatesArray(): FormGroup{
    return new FormGroup({
       dateOfUpdate: new FormControl(""),
       version: new FormControl(""),
       updateDescription: new FormControl(""),
      });
 }

 update(): FormArray {
  return this.updatesForm.get("updates") as FormArray
}
addUpdates() {
  let control = this.updatesForm.get("updates") as FormArray;
  control.push(this.populateUpdatesArray());
}

 removeUpdates(i){
  let control = this.updatesForm.get("updates") as FormArray;
  control.removeAt(i);
}

updatesFormToModel() {
  let modelData = Object.assign({}, capabilitiesData.updatesDTO[0]);
  let formData = this.updatesForm.getRawValue();
    for (let key in formData) {
    if (modelData.hasOwnProperty(key))
      modelData[key] = formData[key] || '';
  };
 console.log("modelData",modelData);
  return modelData;
};
closeUpdatesAddBlock() {
  this.showUpdatesAddBlock=false;
  }

}
