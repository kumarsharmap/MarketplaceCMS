export class ProjectModel {
  projectid: number;
  projectname: string;
}
