import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FoundationService } from '../services/foundation.service';
import { Router } from '@angular/router';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
@Component({
  selector: 'app-create-foundation',
  templateUrl: './create-foundation.component.html',
  styleUrls: ['./create-foundation.component.css']
})
export class CreateFoundationComponent implements OnInit {
  foundationForm: FormGroup;
  colorPaletteitems: FormArray;
  colorPaletteSection: FormArray;
  submitSuccess: boolean = false;
  submitformClicked: boolean = false;
  constructor(private formBuilder: FormBuilder, public foundationServ: FoundationService, private router: Router, private toastNotificationService: ToastNotificationService) { }

  ngOnInit(): void {
    this.foundationForm = this.formBuilder.group({
      pageTitle: new FormControl(),
      pageDescription: new FormControl(),
      colorSection: this.formBuilder.array([this.createColorPaletteSection()]),
    });
    this.fectchDetails();
  }
  fectchDetails() {
    let res = {
      "pageTitle": "colours",
      "pageDescription": "colours component",
      "colorSection": [{
        "description": "primary colours",
        "items": [{
          "colourName": "green",
          "hexaValue": "#11111",
          "rgbValue": "180,180,180"
        }],
        "title": "primary"
      },
      {
        "description": "secondary colours",
        "items": [{
          "colourName": "red",
          "hexaValue": "#FFF2",
          "rgbValue": "255,255,255"
        },
        {
          "colourName": "Black",
          "hexaValue": "#fff3",
          "rgbValue": "0,0,0"
        }
        ],
        "title": "secndary"
      }
      ]
    }
    this.foundationForm.controls['']
  }
  createItem(): FormGroup {
    return this.formBuilder.group({
      colourName: new FormControl(),
      hexaValue: new FormControl(),
      rgbValue: new FormControl()
    });
  }

  createColorPaletteSection(): FormGroup {
    return this.formBuilder.group({
      title: new FormControl(),
      description: new FormControl(),
      items: this.formBuilder.array([this.createItem()])
    });
  }


  addItem(index) {
    this.colorPaletteSection = this.foundationForm.get('colorSection') as FormArray;
    this.colorPaletteitems = this.colorPaletteSection.at(index).get("items") as FormArray;
    this.colorPaletteitems.push(this.createItem());
  }
  addColorPaletteSection(): void {
    this.colorPaletteSection = this.foundationForm.get('colorSection') as FormArray;
    this.colorPaletteSection.push(this.createColorPaletteSection());
  }
  deleteColorPaletteSection(index) {
    let section = this.foundationForm.get('colorSection') as FormArray;
    if (section.length > 1) {
      section.removeAt(index);
    }
  }
  deleteColorPaletteItem(j, i) {
    let section = this.foundationForm.get('colorSection') as FormArray;
    let item = this.colorPaletteSection.at(j).get("items") as FormArray;
    if (item.length > 1) {
      item.removeAt(i);
    }

  }

  hexToRgb(j, i) {

    let section = this.foundationForm.get('colorSection') as FormArray;
    let item = section.at(j).get("items") as FormArray;
    console.log("item", item);
    let hex = item.value[i].hexaValue;
    let testInp = hex.substring(1);
    let check = typeof testInp == 'string' && testInp.length == 6 && !isNaN(Number('0x' + testInp));
    console.log("check ", check);
    if (check == true) {
      var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      let r = parseInt(result[1], 16);
      let g = parseInt(result[2], 16);
      let b = parseInt(result[3], 16);
      let res = "(" + r + "," + g + "," + b + ")";
      item.controls[i]['controls']['rgbValue'].setValue(res);
    } else {
      item.controls[i]['controls']['rgbValue'].setValue("");
    }

  }
  gotoHome() {
    this.router.navigateByUrl('/landing');
  }
  submitForm() {
    this.submitformClicked = true;
    console.log("checkk", this.foundationForm.value);
    let colorSec = [];
    let colorItem = [];
    for (let i = 0; i < this.foundationForm.value.colorSection.length; i++) {
      for (let j = 0; j < this.foundationForm.value.colorSection[i].items.length; j++) {
        colorItem.push({
          colourName: this.foundationForm.value.colorSection[i].items[j].colourName,
          hexaValue: this.foundationForm.value.colorSection[i].items[j].hexaValue,
          rgbValue: this.foundationForm.value.colorSection[i].items[j].rgbValue
        })
      }
      colorSec.push({
        title: this.foundationForm.value.colorSection[i].title,
        description: this.foundationForm.value.colorSection[i].description,
        items: colorItem
      })
      colorItem = [];
    }
    let inputDta = {
      "foundationId": 0,
      "artifactType": "colour",
      "status": "",
      "pageTitle": this.foundationForm.value.pageTitle,
      "pageDescription": this.foundationForm.value.pageDescription,
      "userDetails": {
        "userName": "",
        "tenantId": 0
      },
      "colorSection": colorSec
    }
    console.log("Data to send", inputDta);
    this.foundationServ.colorFormSubmit(inputDta).subscribe(
      response => {
        console.log("API success");
        this.toastNotificationService.showSuccess("Submitted successfully");
        this.submitSuccess = true;
        this.foundationForm.disable();
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed to submit");
      })
  }


}