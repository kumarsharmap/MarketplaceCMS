export class CommonConstants {
  static REGISTER = 'Register Successfully';
}
