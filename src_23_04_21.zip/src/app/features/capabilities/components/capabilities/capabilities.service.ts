import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
//import { map } from 'rxjs/operators';

import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { WebService } from 'src/app/core/services/web.service';

@Injectable({
  providedIn: 'root'
})
export class CapabilitiesService {

  private makerActionUrl;
  private approverActionUrl;
  private deleteRecordUrl;
  private allCapabilitiesUrl;
  private capabilityByIDUrl;
  private approverUpdateUrl;
  private makerUpdateUrl;
  private capabilityByStatusUrl;
  menuItem: any='';


  // makersubmit = '';
  // makerupdate='';
  // adminApprove = '';
  // adminUpdate = '';
  // delete = '';
  // allCapabilities='';
  // capabilityId='';

  constructor(private webService: WebService, private http: HttpClient) {
   
    this.makerActionUrl = '';
    this.makerUpdateUrl = '';
    this.approverActionUrl ='';
    this.approverUpdateUrl ='';
    this.deleteRecordUrl = '';
    this.allCapabilitiesUrl = '';
    this.capabilityByIDUrl = '';
    this.capabilityByStatusUrl='';
   
  }
 
  makerAction(data, http?): Observable<any> {
    return this.http.post(this.makerActionUrl, data, http);
  }
  approverAction(data, http?): Observable<any> {
    return this.http.post(this.approverActionUrl, data, http);
  }
  approverUpdate(data): Observable<any> {
    return this.http.put(this.approverUpdateUrl, data);
  }
  makerUpdateAction(data): Observable<any> {
    return this.http.put(this.makerUpdateUrl, data);
  }
  deleteRecord(id): Observable<any> {
    return this.http.delete(this.deleteRecordUrl + id);
  }
  
  getAllCapabilities(data, http?): Observable<any> {

    return this.http.get(this.allCapabilitiesUrl + data, http);
  }

  getCapabilityByID(id, http?): Observable<any> {
    return this.http.get(this.capabilityByIDUrl + id, http);
  }
  getCapabilityByStatus(status, http?): Observable<any> {
    return this.http.get(this.capabilityByStatusUrl + status, http);
  }
  setSelectedMenuItem(data: any) {
    this.menuItem = data;
    };
    
    getSelectedMenuItem() {
    return this.menuItem;
    };

}
