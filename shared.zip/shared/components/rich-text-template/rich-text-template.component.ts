import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { FoundationService } from 'src/app/features/foundation/components/services/foundation.service';

@Component({
  selector: 'app-rich-text-template',
  templateUrl: './rich-text-template.component.html',
  styleUrls: ['./rich-text-template.component.css']
})
export class RichTextTemplateComponent implements OnInit {
  form: FormGroup;
  imgArray: any;
  submitSuccess: boolean = false;
  responseToBeViewed: any;
  fileName: string = "No file chosen";
  @Input('data') inputDetails;
  quillConfiguration = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],
      ['blockquote', 'code-block'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      [{ color: [] }, { background: [] }],
      ['link'],
      ['image']
    ],
  }
  constructor(public formBuilder: FormBuilder, private router: Router, public loginService: LoginService, public foundationServ: FoundationService, public toastNotificationService: ToastNotificationService) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      title: new FormControl(),
      summary: new FormControl(),
      image: new FormControl(),
      richTextArray: new FormArray([this.createRichTextArray()]),
    });
    if (this.inputDetails.artifactType == 'Foundation' && this.inputDetails.type == 'Edit') {
      this.setValueForm();
    }

  }
  ngOnChanges() {
    if (this.inputDetails.artifactType == 'Foundation' && this.inputDetails.type == 'Edit') {
      this.setValueForm();
    } else {
      this.form.reset();
    }
  }
  setValueForm() {
    this.responseToBeViewed = {
      "image": 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAqgAAAIUCAMAAADhbi5gAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAJdnBBZwAABvoAAAlNAIgNuIsAAAECUExURf///1JQUF5aWm5sbDIwME5KTJuZmSIeIMXDxYuJiT46PCQgICYiIiQgIi4qLFpYWEZERLGvryomKC4qKjo2OHx6eiomJigkJuPh4Xp4eCwoKmRiYjIuMCwqKru5uSgkJExISD46OnZydExISkI+PmRgYqWjoyYiJGBeXkRAQoWDg6mnpzg2NnJwcEA8Pjo4OEhERkJAQJ+dnTAsLMnJyUZCQjg0NGhmZjYyNIWBg1RSUjAsLnh2douJi2poaCwoKEZCRFxaWnh0dlxYWjQwMJ2bm0pGRkhGRvHx8Tw4OOXj49fV1VBOTkRAQGZkZIOBgVhUVkpGSJORkUxKSj48PHBubryzqrAAAB9+SURBVHgB7Zhpc11HckQBEcTFE8BdovZ9j9ljVtkOL2PLuz1e//9fscMA3s1gdXYniXKEQnPeF5Wysx8vzhwWdOfkhA8EIAABCEAAAn9kBC62e4emz799fdH0efLZt03fdPHdX3d908U3/9kE6vD7n3/Z9VSfftP1TRdf/EfTVz15dGj6povzf7z9+9go6kfbD/zzfpeoj3/goBp/vPNbUU+2i+N4x+H+/Tt+wfH6xXY4znccDtsdv2C/vrX9fIezPuiNP9+9/We929Rngtgp492e7qTv8X7wor6PqJlsYqeM2V3bQlSL5oUDNuoLQOy/ip0y2np2gKgZp5MTRE1JiZ0yprdND1ENmBIjakFiArFTRlNOY0RNSSFqSkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Jip4zpbdNDVAOmxIhakJhA7JTRlNMYUVNSiJqSEjtlTG+bHqIaMCVG1ILEBGKnjKacxoiakkLUlJTYKWN62/QQ1YApMaIWJCYQO2U05TRG1JQUoqakxE4Z09umh6gGTIkRtSAxgdgpoymnMaKmpBA1JSV2ypjeNj1ENWBKjKgFiQnEThlNOY0RNSWFqCkpsVPG9LbpIaoBU2JELUhMIHbKaMppjKgpKURNSYmdMqa3TQ9RDZgSI2pBYgKxU0ZTTmNETUkhakpK7JQxvW16iGrAlBhRCxITiJ0ymnIaI2pKClFTUmKnjOlt00NUA6bEiFqQmEDslNGU0xhRU1KImpISO2VMb5seohowJUbUgsQEYqeMppzGiJqSQtSUlNgpY3rb9BDVgCkxohYkJhA7ZTTlNEbUlBSipqTEThnT26aHqAZMiRG1IDGB2CmjKacxoqakEDUlJXbKmN42PUQ1YEqMqAWJCcROGU05jRE1JYWoKSmxU8b0tukhqgFTYkQtSEwgdspoymmMqCkpRE1JiZ0yprdND1ENmBIjakFiArFTRlNOY0RNSSFqSkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Ji5/ZhemnV6xT1zdUflp4ftrS57G2/XlbCQqOoHzf+fPfCx1/W+kzYRT3d+j4PTps+Z33PtG1Nz3TaSeryk66netD48z1veqhPLq+avul0+/b2b8WvtnfOmz5fXZ01fT7YHjU90/n7W9MznZ1tf9r1UK9fPut6qsvGn++jpod66/Ky6ZvOtv1X675cb9191X/2LfyL7fCqD/Hivc5f/fdf/PJX/ffGX/33/1h+9Z8gaqrbhqghqr6VJXbKGD6Gq/U9HhvVMS45G7UgWQaIukR0U+BXf0pK1qiM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Jip4zpbdNDVAOmxIhakJhA7JTRlNMYUVNSiJqSEjtlTG+bHqIaMCVG1ILEBGKnjKacxoiakkLUlJTYKWN62/QQ1YApMaIWJCYQO2U05TRG1JQUoqakxE4Z09umh6gGTIkRtSAxgdgpoymnMaKmpBA1JSV2ypjeNj1ENWBKjKgFiQnEThlNOY0RNSWFqCkpsVPG9LbpIaoBU2JELUhMIHbKaMppjKgpKURNSYmdMqa3TQ9RDZgSI2pBYgKxU0ZTTmNETUkhakpK7JQxvW16iGrAlBhRCxITiJ0ymnIaI2pKClFTUmKnjOlt00NUA6bEiFqQmEDslNGU0xhRU1KImpISO2VMb5seohowJUbUgsQEYqeMppzGiJqSQtSUlNgpY3rb9BDVgCkxohYkJhA7ZTTlNEbUlBSipqTEThnT26aHqAZMiRG1IDGB2CmjKacxoqakEDUlJXbKmN42PUQ1YEqMqAWJCcROGU05jRE1JYWoKSmxU8b0tukhqgFTYkQtSEwgdspoymmMqCkpRE1JiZ0yprdND1ENmBIjakFiArFTRlNOY0RNSSFqSkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Jip4zpbdNDVAOmxIhakJhA7JTRlNMYUVNSiJqSEjtlTG+bHqIaMCVG1ILEBGKnjKacxoiakkLUlNRu56+23543fX75u/SPX/WebJ81PdP5o231h8Xn28O2h3r+JP5TF8V/2Loe6nx7b/Fnxcef/F1cXRR3UU+3vs/lWdPno75n2ramZzo7a3yoy3e7nuqy8amumh7qrcs2E7Z7R5N3Z4/RKw4//nHXX+5Pt8MrPkO59q+NG+dx+fZXDH7y9J0uVL9r/I3xt00P9ebDd5u+6Xz70RFxn6j8N+oR6mLgv1EXgI7HYqeMx+NXGxA15YaoKSmxU8b0tukhqgFTYkQtSEwgdspoymmMqCkpRE1JiZ0yprdND1ENmBIjakFiArFTRlNOY0RNSSFqSkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Jip4zpbdNDVAOmxIhakJhA7JTRlNMYUVNSiJqSEjtlTG+bHqIaMCVG1ILEBGKnjKacxoiakkLUlJTYKWN62/QQ1YApMaIWJCYQO2U05TRG1JQUoqakxE4Z09umh6gGTIkRtSAxgdgpoymnMaKmpBA1JSV2ypjeNj1ENWBKjKgFiQnEThlNOY0RNSWFqCkpsVPG9LbpIaoBU2JELUhMIHbKaMppjKgpKURNSYmdMqa3TQ9RDZgSI2pBYgKxU0ZTTmNETUkhakpK7JQxvW16iGrAlBhRCxITiJ0ymnIaI2pKClFTUmKnjOlt00NUA6bEiFqQmEDslNGU0xhRU1KImpISO2VMb5seohowJUbUgsQEYqeMppzGiJqSQtSUlNgpY3rb9BDVgCkxohYkJhA7ZTTlNEbUlBSipqTEThnT26aHqAZMiRG1IDGB2CmjKacxoqakEDUlJXbKmN42PUQ1YEqMqAWJCcROGU05jRE1JYWoKSmxU8b0tukhqgFTYkQtSEwgdspoymmMqCkpRE1JiZ0yprdND1ENmBIjakFiArFTRlNOY0RNSSFqSkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1K7nefbJ6dNn6un502fr7dnTc90erY1PdP5+XbV9VAPH/y266k+aPz53mh6qDff+qDpm863H90qfb497sL/4Oqs6fN8e970TWcPtr7Pg66Hurp81vVVl1vXN531gdouux5q+/RW1JN9uR6jVxz41Z+C41d/SkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Jip4zpbdNDVAOmxIhakJhA7JTRlNMYUVNSiJqSEjtlTG+bHqIaMCVG1ILEBGKnjKacxoiakkLUlJTYKWN62/QQ1YApMaIWJCYQO2U05TRG1JQUoqakxE4Z09umh6gGTIkRtSAxgdgpoymnMaKmpBA1JSV2ypjeNj1ENWBKjKgFiQnEThlNOY0RNSWFqCkpsVPG9LbpIaoBU2JELUhMIHbKaMppjKgpKURNSYmdMqa3TQ9RDZgSI2pBYgKxU0ZTTmNETUkhakpK7JQxvW16iGrAlBhRCxITiJ0ymnIaI2pKClFTUmKnjOlt00NUA6bEiFqQmEDslNGU0xhRU1KImpISO2VMb5seohowJUbUgsQEYqeMppzGiJqSQtSUlNgpY3rb9BDVgCkxohYkJhA7ZTTlNEbUlBSipqTEThnT26aHqAZMiRG1IDGB2CmjKacxoqakEDUlJXbKmN42PUQ1YEqMqAWJCcROGU05jRE1JYWoKSmxU8b0tukhqgFTYkQtSEwgdspoymmMqCkpRE1JiZ0yprdND1ENmBIjakFiArFTRlNOY0RNSSFqSkrslDG9bXqIasCUGFELEhOInTKachojakoKUVNSYqeM6W3TQ1QDpsSIWpCYQOyU0ZTTGFFTUoiakhI7ZUxvmx6iGjAlRtSCxARip4ymnMaImpJC1JSU2Cljetv0ENWAKTGiFiQmEDtlNOU0RtSUFKKmpMROGdPbpoeoBkyJEbUgMYHYKaMppzGipqQQNSUldsqY3jY9RDVgSoyoBYkJxE4ZTTmNETUlhagpKbFTxvS26SGqAVNiRC1ITCB2ymjKaYyoKSlETUmJnTKmt00PUQ2YEiNqQWICsVNGU05jRE1JIWpKSuyUMb1teohqwJQYUQsSE4idMppyGiNqSgpRU1Jip4zpbdNDVAOmxIhakJhA7JTRlNMYUVNSiJqSEjtlTG+bHqIaMCVG1ILEBGKnjKacxoiakkLUlJTYKWN62/QQ1YApMaIWJCYQO7dvTeel4/u//vuXvjO+cLHdGx+8fHrYXv6OubH95m1z8rLx4f0vX/aK69/fuh7qpA/6x3/pHvdl813Uw9b3uXx41vP5YNt6vujs7K3tjdOmTx+obbvq+vkebE+7vmrbmkD99LLNhO2/btV++9Evzps+/3z1uOkn/ferremZzr/oE/Xp9k7TUx22d5tInT7s+/muttd7Pr/56PLzpp/vjf0X4uG1W2fv+s+Ls4u7fsXt/fv7891Gr/rP7fCqN1+8d9h/D7149LL/vt1/2Ruuf9H587k/5GXzRhN2ERA1/Z8BUVNSiJqSkl7nxmn7jcFGlf+FpiMbdYpneMhGHWIZhGzUAZRVxEZdEbo97/t/8hD1lulL/BNRU1iImpLae7z17yzmE2/9cz6j08aFj6gjwKMMUUdU5hmizvnIKW/9AmM68tY/xTM85K1/iGUQNq4sRB3wXUSIugB0PEbUI4p84K0/ZcVbf0pq7/EytbOYT7xMzfmMThsXPqKOAI8yRB1RmWeIOucjp7z1C4zpyMvUFM/wkJepIZZB2LiyEHXAdxEh6gLQ8RhRjyjygbf+lBVv/SmpvcfL1M5iPvEyNeczOm1c+Ig6AjzKEHVEZZ4h6pyPnPLWLzCmIy9TUzzDQ16mhlgGYePKQtQB30WEqAtAx2NEPaLIB976U1a89aek9h4vUzuL+cTL1JzP6LRx4SPqCPAoQ9QRlXmGqHM+cspbv8CYjrxMTfEMD3mZGmIZhI0rC1EHfBcRoi4AHY8R9YgiH3jrT1nx1p+S2nu8TO0s5hMvU3M+o9PGhY+oI8CjDFFHVOYZos75yClv/QJjOvIyNcUzPORlaohlEDauLEQd8F1EiLoAdDxG1COKfOCtP2XFW39Kau/xMrWzmE+8TM35jE4bFz6ijgCPMkQdUZlniDrnI6e89QuM6cjL1BTP8JCXqSGWQdi4shB1wHcRIeoC0PEYUY8o8oG3/pQVb/0pqb3Hy9TOYj7xMjXnMzptXPiIOgI8yhB1RGWeIeqcj5zy1i8wpiMvU1M8w0NepoZYBmHjykLUAd9FhKgLQMdjRD2iyAfe+lNWvPWnpPYeL1M7i/nEy9Scz+i0ceEj6gjwKEPUEZV5hqhzPnLKW7/AmI68TE3xDA95mRpiGYSNKwtRB3wXEaIuAB2PEfWIIh94609Z8dafktp7vEztLOYTL1NzPqPTxoWPqCPAowxRR1TmGaLO+cgpb/0CYzryMjXFMzzkZWqIZRA2rixEHfBdRIi6AHQ8RtQjinzgrT9lxVt/Smrv8TK1s5hPvEzN+YxOGxc+oo4AjzJEHVGZZ4g65yOnvPULjOnIy9QUz/CQl6khlkHYuLIQdcB3ESHqAtDxGFGPKPKBt/6UFW/9Kam9x8vUzmI+8TI15zM6bVz4iDoCPMoQdURlniHqnI+c8tYvMKYjL1NTPMNDXqaGWAZh48pC1AHfRYSoC0DHY0Q9osgH3vpTVt/zt/733v3Dec/nned/ljJZ9f5l+/OeZzo/336++sPS8ze3z9oe6uzt9E9d9D7cHl80fe5tF4s/LD2+ePokra56+6/+z7eHZz2fdzc+EOgmcO+octvfo5O+d9kv+35hv7d1rcHD9vER2h2HPzw8b1qDH/5s3zl3fKi3t0ddqLbP7/gsx+v3Dsfx+yjq9/L/HWz8i3g46/ote/K9/L+c+1bWAVGPf1PjoRE/oobUETUEpTVEVRqzuZEUG3UGenzWiJ+NOkZcUjZqQbIOEHXN6LrRSIqNmkLfe4342ag71unERp3iGR8i6phLTRtJsVEr3lXSiJ+NuoJ9c85GDUFpDVGVxmxuJMVGnYEenzXiZ6OOEZeUjVqQrANEXTO6bjSSYqOm0PdeI3426o51OrFRp3jGh4g65lLTRlJs1Ip3lTTiZ6OuYN+cs1FDUFpDVKUxmxtJsVFnoMdnjfjZqGPEJWWjFiTrAFHXjK4bjaTYqCn0vdeIn426Y51ObNQpnvEhoo651LSRFBu14l0ljfjZqCvYN+ds1BCU1hBVaczmRlJs1Bno8VkjfjbqGHFJ2agFyTpA1DWj60YjKTZqCn3vNeJno+5YpxMbdYpnfIioYy41bSTFRq14V0kjfjbqCvbNORs1BKU1RFUas7mRFBt1Bnp81oifjTpGXFI2akGyDhB1zei60UiKjZpC33uN+NmoO9bpxEad4hkfIuqYS00bSbFRK95V0oifjbqCfXPORg1BaQ1RlcZsbiTFRp2BHp814mejjhGXlI1akKwDRF0zum40kmKjptD3XiN+NuqOdTqxUad4xoeIOuZS00ZSbNSKd5U04mejrmDfnLNRQ1BaQ1SlMZsbSbFRZ6DHZ4342ahjxCVloxYk6wBR14yuG42k2Kgp9L3XiJ+NumOdTmzUKZ7xIaKOudS0kRQbteJdJY342agr2DfnbNQQlNYQVWnM5kZSbNQZ6PFZI3426hhxSdmoBck6QNQ1o+tGIyk2agp97zXiZ6PuWKcTG3WKZ3yIqGMuNW0kxUateFdJI3426gr2zTkbNQSlNURVGrO5kRQbdQZ6fNaIn406RlxSNmpBsg4Qdc3outFIio2aQt97jfjZqDvW6cRGneIZHyLqmEtNG0mxUSveVdKIn426gn1zzkYNQWkNUZXGbG4kxUadgR6fNeJno44Rl5SNWpCsA0RdM7puNJJio6bQ914jfjbqjnU6sVGneMaHiDrmUtNGUmzUineVNOJno65g35yzUUNQWkNUpTGbG0mxUWegx2eN+NmoY8QlZaMWJOsAUdeMrhuNpNioKfS914ifjbpjnU5s1Cme8SGijrnUtJEUG7XiXSWN+NmoK9g352zUEJTWEFVpzOZGUmzUGejxWSN+NuoYcUnZqAXJOkDUNaPrRiMp2agfpn/8qtf3eBfb/nyrP3VxftgWhfy47+c7sFFD7PtG/cn2F2dNn+3BadPnZ9uzpm86/eV23vXZrroe6tnlT7u+6mrr+qbT7ZsmUl9sX3U91N/81a3R59vjri/drpqMP3u6vdH1UM+3roc6297qeqhnl8+6nuqy8efb2j6XXT/eRx/finqyXRzHOw59vxr51R//T3G/8T9t2v57q8+E/Vc/osZONOLnv1FD6ogagtIaoiqN2dxIat/y/OqfIdezRvxsVAU7mdmoEzjuCFEdmRfzRlJs1Bfhrv+9ET8bdY37/xps1BCU1hBVaczmRlJs1Bno8VkjfjbqGHFJ2agFyTpA1DWj60YjKTZqCn3vNeJno+5YpxMbdYpnfIioYy41bSTFRq14V0kjfjbqCvbNORs1BKU1RFUas7mRFBt1Bnp81oifjTpGXFI2akGyDhB1zei60UiKjZpC33uN+NmoO9bpxEad4hkfIuqYS00bSbFRK95V0oifjbqCfXPORg1BaQ1RlcZsbiTFRp2BHp814mejjhGXlI1akKwDRF0zum40kmKjptD3XiN+NuqOdTqxUad4xoeIOuZS00ZSbNSKd5U04mejrmDfnLNRQ1BaQ1SlMZsbSbFRZ6DHZ4342ahjxCVloxYk6wBR14yuG42k2Kgp9L3XiJ+NumOdTmzUKZ7xIaKOudS0kRQbteJdJY342agr2DfnbNQQlNYQVWnM5kZSbNQZ6PFZI3426hhxSdmoBck6QNQ1o+tGIyk2agp97zXiZ6PuWKcTG3WKZ3yIqGMuNW0kxUateFdJI3426gr2zTkbNQSlNURVGrO5kRQbdQZ6fNaIn406RlxSNmpBsg4Qdc3outFIio2aQt97jfjZqDvW6cRGneIZHyLqmEtNG0mxUSveVdKIn426gn1zzkYNQWkNUZXGbG4kxUadgR6fNeJno44Rl5SNWpCsA0RdM7puNJJio6bQ914jfjbqjnU6sVGneMaHiDrmUtNGUmzUineVNOJno65g35yzUUNQWkNUpTGbG0mxUWegx2eN+NmoY8QlZaMWJOsAUdeMrhuNpNioKfS914ifjbpjnU5s1Cme8SGijrnUtJEUG7XiXSWN+NmoK9g352zUEJTWEFVpzOZGUmzUGejxWSN+NuoYcUnZqAXJOkDUNaPrRiMpNmoKfe814mej7linExt1imd8iKhjLjVtJMVGrXhXSSN+NuoK9s05GzUEpTVEVRqzuZEUG3UGenzWiJ+NOkZcUjZqQbIOEHXN6LrRSIqNmkLfe4342ag71unERp3iGR8i6phLTRtJsVEr3lXSiJ+NuoJ9c85GDUFpDVGVxmxuJMVGnYEenzXiZ6OOEZeUjVqQrANEXTO6bjSSYqOm0PdeI3426o51OrFRp3jGh4g65lLTRlJs1Ip3lTTiZ6OuYN+cs1FDUFpDVKUxmxtJHTfqYev7vP9a0+cXfc+0bU3P9NprjQ/14H7XU33V+FSnh57P11dPu3681z+d/YV4xbOLts+Td9q+6vDfPfD/91sef9f1VN+91/ZQf3LoeqiLR10P9eaj17oe6sk/vaKMXIMABCAAAQhAAAIQgMD/J4H/Ac3gG5GPA1CCAAAAAElFTkSuQmCC',
      "summary": "This is the all new CS Marketplace, over here you will find a single repository of all of our components and tech capabilities across the entire Credit Suisse program.",
      "title": "Setup Guide",
      "richTextArray": [
        {
          "richText": "<h1>Setting Up Sketch</h1><p>Hi am a paragraph</p>",
        },
        {
          "richText": "<h1>Setting Up Sketch</h1><p>Hi am a paragraph</p>",
        },
      ],
    };
    this.form.get('title').setValue(this.responseToBeViewed.title);
    this.form.get('summary').setValue(this.responseToBeViewed.summary);
    this.form.get('image').setValue(this.responseToBeViewed.image);

    for (let i = 0; i < this.responseToBeViewed.richTextArray.length; i++) {
      if (i != 0) {
        this.addRichText();
      }
      let arry = this.form.get('richTextArray') as FormArray;
      arry.controls[i]['controls']['richText'].setValue(this.responseToBeViewed.richTextArray[i].richText);
    }
  }
  formSubmit() {
    const formData = new FormData();
    formData.append('file', this.imgArray, this.fileName);
    console.log("Form Data", formData);
    let obj = {
      "foundationId": 0,
      "artifactType": "others",
      "status": "",
      "image": formData,
      "userDetails": {
        "userName": this.loginService.userName,
        "tenantId": this.foundationServ.getApprovalHeaderData(),
      },
      "summary": this.form.value.summary,
      "title": this.form.value.title,
      "richTextArray": this.form.value.richTextArray
    }
    console.log("values to submit", obj);
    this.foundationServ.othersFoundationFormSubmit(obj).subscribe(
      response => {
        console.log("API success");
        this.toastNotificationService.showSuccess("Submitted successfully");
        this.submitSuccess = true;
        this.form.disable();
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed to submit");
      })

  }
  createRichTextArray(): FormGroup {
    return this.formBuilder.group({
      richText: new FormControl([
        {
          "richText": "<h1>Setting Up Sketch</h1><p>Hi am a paragraph</p>",
        }
      ])
    });
  }
  deleteRichTextSection(index) {
    let section = this.form.get('richTextArray') as FormArray;
    if (section.length > 1) {
      section.removeAt(index);
    }

  }
  addRichText() {
    let seciton = this.form.get('richTextArray') as FormArray;
    seciton.push(this.createRichTextArray());
  }
  onFileChange(event) {
    console.log('readUrl', event);
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      if (event.target.files && event.target.files.length) {
        const [file] = event.target.files;
        reader.readAsDataURL(file);

        reader.onload = () => {
          //this.imgArray = reader.result as string;
          this.imgArray = event.target.files[0];
          console.log("img to be sent", event.target.files);
        };

      }

    }
    console.log("file check", event.target.files);

    if (event.target.files.length > 0) {
      this.fileName = event.target.files[0].name;
    } else {
      this.fileName = "No file chosen"
    }

  }
  refreshForm() {
    this.form.reset();
  }
  saveForm() {
    const formData = new FormData();
    formData.append('file', this.imgArray, this.fileName);
    console.log("Form Data", formData);
    let obj = {
      "foundationId": 0,
      "artifactType": "others",
      "status": "Draft",
      "image": formData,
      "userDetails": {
        "userName": this.loginService.userName,
        "tenantId": this.foundationServ.getApprovalHeaderData(),
      },
      "summary": this.form.value.summary,
      "title": this.form.value.title,
      "richTextArray": this.form.value.richTextArray
    }
    console.log("values to submit", obj);
    this.foundationServ.othersFoundationFormSubmit(obj).subscribe(
      response => {
        console.log("API success");
        this.toastNotificationService.showSuccess("Submitted successfully");
        this.submitSuccess = true;
        this.form.disable();
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed to submit");
      })

  }
  gotoHome() {
    this.router.navigateByUrl('/landing');
  }

}
