import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { LoginResponse } from 'src/app/core/models/header-menu.model';
import { CreateLoginRequest } from 'src/app/core/models/login.model';
import { HttpClientHelper } from 'src/http-client-helper';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  static isLogIn: boolean;
  public userName: string;
  public userId: number;
  public loginResponse: LoginResponse[];
  public authentication$: BehaviorSubject<
    LoginResponse[]
  > = new BehaviorSubject(null);
  public loginEmail: string;
  public isSuperAdmin: boolean;
  public loginPassword: string;

  constructor(private http: HttpClient, private router: Router) {}

  // public loginUser(loginData: CreateLoginRequest, isRoting: boolean): void {
  //   this.http.post(`${HttpClientHelper.LOGIN}`, loginData).subscribe(
  //     (login: LoginResponse[]) => {
  //       this.authentication$.next(login);
  //       this.userName = login[0].name;
  //       this.loginResponse = login;
  //       this.isGetlogInUserName();
  //       if (isRoting) {
  //         this.router.navigateByUrl('/landing');
  //       }
  //     },
  //     (error: HttpErrorResponse) => {
  //       throw new Error(error.error.message);
  //     }
  //   );
  // }

  public loginUser(loginData: CreateLoginRequest, isRoting: boolean): void {
    this.http.get(`${HttpClientHelper.LOGIN}`).subscribe(
      (login: LoginResponse[]) => {
        this.authentication$.next(login);
        this.userName = login[0].name;
        this.userId = login[0].userId;
        this.loginResponse = login;
        if (isRoting) {
          this.router.navigateByUrl('/landing');
        }
      },
      (error: HttpErrorResponse) => {
        throw new Error(error.error.message);
      }
    );
  }

  public getUserSubject(): Observable<LoginResponse[]> {
    return this.authentication$;
  }

  public hasRoles(roles: any): boolean {
    if (roles.roleName === 'Admin') {
      return true;
    } else {
      return false;
    }
  }

  isSetlogIn(isLogin): void {
    LoginService.isLogIn = isLogin;
  }

  isGetlogIn(): boolean {
    return LoginService.isLogIn;
  }

  isGetlogInUserName(): string {
    return this.userName;
  }

  setLoginEmail(loginEmail) {
    this.loginEmail = loginEmail;
  }

  getLoginEmail() {
    return this.loginEmail;
  }

  setLoginPassword(loginPassword) {
    this.loginPassword = loginPassword;
  }

  getLoginPassword(): string {
    return this.loginPassword;
  }

  setSuperAdmin(superAdmin) {
    this.isSuperAdmin = superAdmin;
  }

  getSuperAdmin(): boolean {
    return this.isSuperAdmin;
  }
}
