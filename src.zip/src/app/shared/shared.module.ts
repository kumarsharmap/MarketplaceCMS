import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ConfirmWindowComponent } from './components/confirm-window/confirm-window.component';

@NgModule({
  declarations: [ConfirmWindowComponent],
  imports: [CommonModule, RouterModule],
  exports: [ConfirmWindowComponent],
})
export class SharedModule {}
