import { HasRoleDirective } from './has-role.directive';

describe('HasRoleDirective', () => {});
