import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-guides-for-designers',
  templateUrl: './top-guides-for-designers.component.html',
  styleUrls: ['./top-guides-for-designers.component.css']
})
export class TopGuidesForDesignersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
