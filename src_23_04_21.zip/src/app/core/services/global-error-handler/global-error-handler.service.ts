import {
  ErrorHandler,
  Inject,
  Injectable,
  Injector,
  NgZone,
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class GlobalErrorHandlerService implements ErrorHandler {
  constructor(
    @Inject(Injector) private readonly injector: Injector,
    private zone: NgZone
  ) {}

  handleError(error: Error | HttpErrorResponse) {
    if (error instanceof HttpErrorResponse) {
      this.zone.run(() => {
        this.toastrService.error(error.message);
      });
    } else {
      console.log(error);
    }
  }

  private get toastrService(): ToastrService {
    return this.injector.get(ToastrService);
  }
}
