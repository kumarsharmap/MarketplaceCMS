import { Component, OnInit, ViewChild } from '@angular/core';
import { RoleModel } from 'src/app/core/models/roles.model';
import { ConfirmWindowComponent } from 'src/app/shared/components/confirm-window/confirm-window.component';
import { RoleService } from '../../services/role/role.service';
import { AddRoleComponent } from '../add-role/add-role.component';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css'],
})
export class RolesComponent implements OnInit {
  @ViewChild(AddRoleComponent)
  addRoleComponent: AddRoleComponent;
  @ViewChild(ConfirmWindowComponent)
  confirmWindowComponent: ConfirmWindowComponent;
  deleteRole: RoleModel;
  roleData: RoleModel[];
  constructor(private roleService: RoleService) {}

  ngOnInit(): void {
    this.getRoleData();
  }

  onOpenModal(): void {
    this.addRoleComponent.openModal();
  }

  public onRoleEdit(role): void {
    this.addRoleComponent.openRoleModalEdit(role);
  }

  public onDeleteRole(): void {
    if (this.deleteRole) {
      this.confirmWindowComponent.openModal();
    }
  }

  public onDeleteCheckbox(event: Event, id: number): void {
    this.deleteRole = this.roleData.find(
      (item: RoleModel) => item.roleId === id
    );
  }

  public onClickYes(): void {
    this.roleService.removeRole(this.deleteRole.roleId).subscribe(() => {
      this.getRoleData();
      delete this.deleteRole;
    });
  }

  public onClickNo(): void {}

  public getRoleData(): void {
    this.roleService.getRole().subscribe(
      (data) => {
        if (data) {
          this.roleData = data;
        }
      },
      (error) => {
        throw new Error(error.error.message);
      }
    );
  }
}
