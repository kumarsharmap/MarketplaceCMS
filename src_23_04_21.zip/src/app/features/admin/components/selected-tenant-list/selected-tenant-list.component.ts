import { Component, OnDestroy, OnInit } from '@angular/core';
import { CreateTenantModel } from 'src/app/core/models/tenant.model';
import { ApprovalQueueService } from '../../services/approval-queue.service';

@Component({
  selector: 'app-selected-tenant-list',
  templateUrl: './selected-tenant-list.component.html',
  styleUrls: ['./selected-tenant-list.component.css'],
})
export class SelectedTenantListComponent implements OnInit, OnDestroy {
  artifactName: string;
  tenantList: CreateTenantModel[];
  fliterTenantList: CreateTenantModel[] = [];

  constructor(private approvalQueueService: ApprovalQueueService) {}

  ngOnInit(): void {
    this.fliterTenantList = this.approvalQueueService.geTenant();
  }

  // ngOnInit(): void {
  //   this.artifactName = this.approvalQueueService.getArtifactName();
  //   this.tenantList = this.approvalQueueService.geTenant();
  //   this.tenantList.forEach((element: CreateTenantModel) => {
  //     if (element.artifactCategory === this.artifactName) {
  //       this.fliterTenantList.push(element);
  //     }
  //   });
  // }

  ngOnDestroy() {
    this.fliterTenantList = [];
  }
}
