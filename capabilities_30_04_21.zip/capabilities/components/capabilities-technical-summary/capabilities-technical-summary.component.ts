import { Component, OnInit } from '@angular/core';

import { capabilitiesData } from '../capabilities/capabilities.model';
import { FormControl, FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-capabilities-technical-summary',
  templateUrl: './capabilities-technical-summary.component.html',
  styleUrls: ['./capabilities-technical-summary.component.css']
})
export class CapabilitiesTechnicalSummaryComponent implements OnInit {
  technicalSummaryForm:FormGroup;
  showExamplesAddBlock: boolean=true;
  fileName: any='Select a file';
  quillConfiguration = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],
      ['blockquote', 'code-block'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      [{ color: [] }, { background: [] }],
      ['link'],
      ['image']
    ],
  }

  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
     this.technicalSummaryForm =  this.fb.group({
      // pageTitle:['', [Validators.required,Validators.maxLength(80), Validators.pattern("[a-zA-Z0-9_]+.*$")]],
      // description:['',[Validators.required,Validators.maxLength(3000), Validators.pattern("[a-zA-Z0-9_]+.*$")]], 
      previews: new FormArray([this.populatePreviewsArray()]),
      richTextBlock: new FormArray([this.populateRichTextArray()]),

    });
console.log("examples",this.richTxt().controls[0]['controls'].blockTitle);
  }


  examples(): FormArray {
    return this.technicalSummaryForm.get("previews") as FormArray
  }
   images(index:number) : FormArray {
    return this.examples().at(index).get("previewImages") as FormArray
  }
    codes(index:number) : FormArray {
    return this.examples().at(index).get("codeSection") as FormArray
  }
  richTxt(): FormArray {
    return this.technicalSummaryForm.get("richTextBlock") as FormArray
  }

  populatePreviewsArray(): FormGroup {
    return new FormGroup({
      blockTitle: new FormControl("",Validators.maxLength(50)),
      summdescription: new FormControl("",Validators.maxLength(80)),
      previewImages: new FormArray([this.populatePreviwImagesArray()]),
      codeSection: new FormArray([this.populateCodeSectionArray()]),
    });
  }
  populatePreviwImagesArray(): FormGroup{
  return new FormGroup({
     previewImage: new FormControl("")
    });
  }

  populateCodeSectionArray(): FormGroup{
     return new FormGroup({
     syntax: new FormControl(""),
     code: new FormControl("",Validators.maxLength(5000))
    });
  }
  populateRichTextArray(): FormGroup{
     return new FormGroup({
     blockTitle: new FormControl("",Validators.maxLength(50)),
     richText: new FormControl("",Validators.maxLength(800))
    });
  }
  
  setPreviews() {
    let control = <FormArray>this.technicalSummaryForm.controls.previews;
    capabilitiesData.examplesDTO[0].previews.forEach(x => {
      control.push(this.fb.group({ 
        blockTitle: x['blockTitle'], 
        summdescription: x['summdescription'],
        previewImages: this.setPreviewImages(x['previewImages']),
        codeSection: this.setCodeSection(x['codeSection'])}))
    })
  }
  setRichText() {
    let control = <FormArray>this.technicalSummaryForm.controls.richTextBlock;
    capabilitiesData.examplesDTO[0].richTextBlock.forEach(x => {
      control.push(this.fb.group({ 
        blockTitle: x['blockTitle'], 
        richText: x['richText']
        }))
    })
  }
  
  setPreviewImages(x) {
    let arr = new FormArray([])
    x.forEach(y => {
      arr.push(this.fb.group({ 
        previewImage: y['previewImage'] 
      }))
    })
    return arr;
  }
    
  setCodeSection(x) {
    let arr = new FormArray([])
    x.forEach(y => {
      arr.push(this.fb.group({ 
        syntax: y['syntax'],
        code: y['code'] 
      }))
    })
    return arr;
  }
  addPreviews() {
    let control = this.technicalSummaryForm.get("previews") as FormArray;
    control.push(this.populatePreviewsArray());
  }
  addRichText() {
    let control = this.technicalSummaryForm.get("richTextBlock") as FormArray;
    control.push(this.populateRichTextArray());
  }
   addCode(i) {
    let control = this.examples().at(i).get("codeSection") as FormArray;
    control.push(this.populateCodeSectionArray());
  }
  removePreviews(i) {
    let control = this.technicalSummaryForm.get("previews") as FormArray;
    control.removeAt(i);
  }
   removeCode(i,codeIdx) {
    let control =  this.examples().at(i).get("codeSection") as FormArray;
    control.removeAt(codeIdx);
  }
  removeRichText(i){
    let control = this.technicalSummaryForm.get("richTextBlock") as FormArray;
    control.removeAt(i);
  }
  closeExamplesAddBlock() {
    this.showExamplesAddBlock=false;
    }
    examplesFormToModel() {
      let modelData = Object.assign({}, capabilitiesData.examplesDTO[0]);
      let formData = this.technicalSummaryForm.getRawValue();
        for (let key in formData) {
        if (modelData.hasOwnProperty(key))
         modelData[key] = formData[key] || '';
        }
             
       
     console.log("modelData",modelData);
      return modelData;
    };

   onFileChange(event){
    console.log("img url",event.target.files);
    this.fileName =event.target.files[0].name;
      if (event.target.files[0].type == "image/jpeg" || event.target.files[0].type == "image/jpg" || event.target.files[0].type == "image/png") {
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]); // read file as data url
        reader.onload = (event) => { // called once readAsDataURL is completed 
          let imgArray = this.fileName+"_"+reader.result;
          console.log("img url",imgArray);
          //this.imgWidth = '400px'; 
          //this.imgHeight = '100px';
      
        }
      //   this.examples().at(0).get("previewImages")['controls'][0]['controls']['previewImage'].setValue(event.target.files);
      // console.log("image value after setting",   this.examples().at(0).get("previewImages")['controls'][0]['controls']['previewImage'].value);
      }
    
    
  }
}
