export class ArtifactoryModel {
  id: number;
  artifactoryName: string;
}
