import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-components-updates',
  templateUrl: './latest-components-updates.component.html',
  styleUrls: ['./latest-components-updates.component.css']
})
export class LatestComponentsUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
