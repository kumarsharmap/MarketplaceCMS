export class LoginResponse {
  artifactName: string;
  name: string;
  userId: number;
  isSuperAdmin: string;
  customTenantList: TenantList[];
}

export class TenantList {
  roleId: number;
  tenantId: number;
  tenantName: string;
  roleName: string;
  artifactCategory: string;
}
