import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-guides-for-developers',
  templateUrl: './top-guides-for-developers.component.html',
  styleUrls: ['./top-guides-for-developers.component.css']
})
export class TopGuidesForDevelopersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
