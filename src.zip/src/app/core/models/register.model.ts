export class RegisterModel {
  email: number;
  name: string;
  tenantUser: TenantUser;
}

export class TenantUser {
  tenantId: number;
  tenantName: string;
}
