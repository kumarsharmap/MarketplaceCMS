import { Component, Input, OnInit } from '@angular/core';
import { LoginResponse } from '../../models/header-menu.model';
import { MenuService } from '../../services/menu/menu.service';
import { ParentSubscriptionComponent } from '../parent-subscription/parent-subscription.component';

@Component({
  selector: 'app-header-admin',
  templateUrl: './header-admin.component.html',
  styleUrls: ['./header-admin.component.css'],
})
export class HeaderAdminComponent
  extends ParentSubscriptionComponent
  implements OnInit {
  @Input() isAdminMenu: boolean;
  capabilitiesMenu: LoginResponse;
  constructor(private menuService: MenuService) {
    super();
  }

  ngOnInit(): void {
    this.menuService.menu$.subscribe((item) => {
      if (item) {
        this.capabilitiesMenu = item;
      }
    });
  }
}
