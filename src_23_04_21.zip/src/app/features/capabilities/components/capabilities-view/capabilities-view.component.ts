import { Component, OnInit, Input } from '@angular/core';
import { TabDirective, TabsetComponent } from "ngx-bootstrap/tabs";
import { CapabilitiesService } from '../capabilities/capabilities.service';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
import { HttpErrorResponse } from '@angular/common/http';
import { capabilitiesData,imageValue } from '../capabilities/capabilities.model';
@Component({
  selector: 'app-capabilities-view',
  templateUrl: './capabilities-view.component.html',
  styleUrls: ['./capabilities-view.component.css']
})
export class CapabilitiesViewComponent implements OnInit {
  @Input('selectedCapabilityId') capabilityId: number;
  headings = [];
  tabHeading: string = "Technical Summary";
  imgUrl: string;
  pageTitle = "<p><strong>gayathri</strong></p><p><strong><em>tummala</em></strong></p><p><u>hcl</u></p><p><s>bangalore</s></p>"
  
  selectedCapability: any={
    status:"03",
    capabilitiesId:1,
    pageTitle:"Position Lists",
    description: "A button triggers an event or action. They let users know what will happen next.",
    userDetails: {
      userName:"test",
      tenantId:0
    },
  
    examplesDTO: [{
      previews:[{
      blockTitle: "Position List",
      summdescription: "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
      previewImages:[{
      previewImage:imageValue
      }
      ],
      codeSection:[{
        syntax: "HTML",
        code: "body {↵  display: grid;↵  grid-template-rows: repeat(7, 1fr);↵  place-items: center;↵  overflow: hidden;↵}"
       },
       {
        syntax: "CSS",
        code: ".w-icon-slider-right:before {↵  content: "+"\e600"+";↵}↵.w-icon-slider-left:before {↵  content: "+"\e601"+";↵}↵.w-icon-nav-menu:before {↵  content: "+"\e602"+";↵}"
       }],
      },
      {
        blockTitle: "Position List",
        summdescription: "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        previewImages:[{
        previewImage:imageValue
        }
        ],
        codeSection:[{
          syntax: "HTML",
          code: "body {↵  display: grid;↵  grid-template-rows: repeat(7, 1fr);↵  place-items: center;↵  overflow: hidden;↵}"
         },
         {
          syntax: "CSS",
          code: ".w-icon-slider-right:before {↵  content: "+"\e600"+";↵}↵.w-icon-slider-left:before {↵  content: "+"\e601"+";↵}↵.w-icon-nav-menu:before {↵  content: "+"\e602"+";↵}"
         }],
        }   
      ],
      richTextBlock:[{
        blockTitle: "Backend Services",
        richText:"Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
      },
      {
        blockTitle: "Security Services",
        richText:"Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
      }]
    }
    ],
    
    resourcesDTO: [
      {
      resourceName: "Invision Location",
      linkLocation: "invisionapp.com/4726bsHCY..."
      },
      {
        resourceName: "Sketch Location",
        linkLocation: "Toolkit / Misc / Buttons"
        },
        {
          resourceName: "Bitbucket",
          linkLocation: "bitbucket.org/cs-kit/38cnsas"
          }
    ],
    
    updatesDTO: [
      { 
      dateOfUpdate:"28 Jan 2020",
      version: "Version 70.2",
      updateDescription: "<ul><li>Use breadcrumbs when the user is most likely to have landed on the page from an external source.</li></ul>"}]
  };
  code: any;

  constructor(private capabilityService: CapabilitiesService, private toastNotificationService: ToastNotificationService) {
    this.headings = [
      { tabTitle: "Technical Summary" },
      { tabTitle: "Resources" },
      { tabTitle: "Updates" }
    ]
  }

  ngOnInit(): void {
    //this.imgUrl = this.imageValue;
   // this.getSelectedCapabilityDetails();
// return (this.selectedCapability.examplesDTO[0].previews[0].codeSection[0].code).replace(/(?:\r\n|\r|\n)/g, '<br />');
// console.log("parsed code",this.code);  
}
// parseHTML(){
//   return (this.selectedCapability.examplesDTO[0].previews[0].codeSection[0].code).replace(/\u21B5/g,'\n');
// }
  confirmTabSwitch(data: TabDirective): void {
    this.tabHeading = data.heading;
    console.log(this.tabHeading);
  }

  subTabSwitch(data: TabDirective): void {
    // this.tabHeading = data.heading;
    console.log(data.heading);
  }

  getSelectedCapabilityDetails() {
    this.capabilityService.getCapabilityByID(this.capabilityId).subscribe(
      res => {
        this.selectedCapability = res;
      },
      (error: HttpErrorResponse) => {
        this.toastNotificationService.showError(error.error.message);
        throw new Error(error.error.message);

      }

    )

  }
}



