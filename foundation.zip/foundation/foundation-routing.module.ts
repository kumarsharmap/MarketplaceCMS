import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FoundationHomeComponent } from './components/foundation-home/foundation-home.component';
import { FoundationComponent } from './components/foundation/foundation.component';


const routes: Routes = [
  {
    path: '',
    component: FoundationComponent,
  },
  {
    path: 'foundationHome',
    component: FoundationHomeComponent, outlet: 'subFoundation'
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FoundationRoutingModule { }
