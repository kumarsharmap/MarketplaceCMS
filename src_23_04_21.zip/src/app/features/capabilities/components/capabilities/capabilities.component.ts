import { Component, OnInit, ViewChild, OnChanges } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder, FormsModule } from '@angular/forms';
import { MenuService } from 'src/app/core/services/menu/menu.service';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { capabilitiesData,imageValue } from '../capabilities/capabilities.model';
import { TabDirective, TabsetComponent } from "ngx-bootstrap/tabs";
import { Subject } from 'rxjs';
import { CapabilitiesService } from './capabilities.service';
import { takeUntil } from 'rxjs/operators';
import { Route, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';

@Component({
  selector: 'app-capabilities',
  templateUrl: './capabilities.component.html',
  styleUrls: ['./capabilities.component.css'],
})
export class CapabilitiesComponent implements OnInit {
  @ViewChild("tabset") tabset: TabsetComponent;

  forms = new FormGroup({});
  form2 = new FormGroup({});
  form3 = new FormGroup({});
  options= [
               { label: "HTML", value: "html" },
               { label: "JS", value: "js" }
             ]
 myobj1 = capabilitiesData.examplesDTO[0].previews[0];
 myobj11 = capabilitiesData.examplesDTO[0].richTextBlock[0];
 myobj2= capabilitiesData.resourcesDTO[0];
 myObj3 = capabilitiesData.updatesDTO[0];
 headings=[];
 tabHeading: string = "Technical Summary";
 description="";
 pageTitle="";
 showForm:boolean=false;
 status="approved";
 private onDestroy$: Subject<void>;
  capabilitiesArray: any=[];
  draftList: any = [];
  approvedList:any=[];
  showHome: boolean = true;
  showCapability: boolean = false;
  tenantName: any;
  quillConfiguration = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],
      ['blockquote', 'code-block'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      [{ color: [] }, { background: [] }],
      ['link'],
      ['image']
    ],
  }
  selectedCapabilityId=0;
  showExamplesAddBlock: boolean =true;
  showResourcesAddBlock: boolean=true;
  showUpdatesAddBlock: boolean=true;

  constructor(public capabilityService:CapabilitiesService, private fb:FormBuilder,
    private toastNotificationService:ToastNotificationService, private route:Router) { 
    if (this.route.getCurrentNavigation().extras.queryParams != undefined) {
        this.tenantName = this.route.getCurrentNavigation().extras.queryParams.tenantName;

    }
    this.headings=[
    {tabTitle:"Technical Summary"},
    {tabTitle:"Resources"},
    {tabTitle:"Updates"}
  ]
  this.onDestroy$ = new Subject<void>();
  }

  cancel(){
    this.forms.reset();
    this.form2.reset();
    this.form3.reset();
  }

  loadData(tab) {
   console.log("tab selected",tab)
    if (tab == "home") {
      this.showHome = true;
      this.showCapability = false;
      this.showForm = false;
    }
    else if (tab == "create") {
      this.showCapability = false;
      this.showHome = false;
      this.showForm = true;
    }
    else {
      if(this.status == 'approved'){
        this.selectedCapabilityId = tab.capabilitiesId;
        for(let i in this.approvedList){
          if(this.approvedList[i].pageTitle == tab.pageTitle){
            this.showCapability = true;
            this.showHome = false;
            this.showForm = false;
          }
          
        }
      
      }
      else{
        for(let i in this.approvedList){
        if(this.draftList[i].pageTitle == tab.pageTitle){
        this.showCapability = false;
        this.showHome = false;
        this.showForm = true;
      }
    }
    }
  }
  }

  confirmTabSwitch(data: TabDirective): void {
    this.tabHeading = data.heading;
    console.log(this.tabHeading);
  }

   ngOnInit(): void {
     this.getApprovedList();
     this.getDraftList();
    //this.approvedList =['Position Lists','Portfolios','Currency Allocation'];
    this.approvedList=[{
      status:"03",
      capabilitiesId:1,
      pageTitle:"Position Lists",
      description: "A button triggers an event or action. They let users know what will happen next.",
      userDetails: {
        userName:"test",
        tenantId:0
      },
    
      examplesDTO: [{
        previews:[{
        blockTitle: "Position List",
        summdescription: "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        previewImages:[{
        previewImage:""
        }
        ],
        codeSection:[{
          syntax: "HTML",
          code: "body {↵  display: grid;↵  grid-template-rows: repeat(7, 1fr);↵  place-items: center;↵  overflow: hidden;↵}"
         },
         {
          syntax: "CSS",
          code: ".w-icon-slider-right:before {↵  content: "+"\e600"+";↵}↵.w-icon-slider-left:before {↵  content: "+"\e601"+";↵}↵.w-icon-nav-menu:before {↵  content: "+"\e602"+";↵}"
         }],
        }   
        ],
        richTextBlock:[{
          blockTitle: "Backend Services",
          richText:"Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        },
        {
          blockTitle: "Security Services",
          richText:"Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        }]
      }],
      
      resourcesDTO: [
        {
        resourceName: "Invision Location",
        linkLocation: "invisionapp.com/4726bsHCY..."
        },
        {
          resourceName: "Sketch Location",
          linkLocation: "Toolkit / Misc / Buttons"
          },
          {
            resourceName: "Bitbucket",
            linkLocation: "bitbucket.org/cs-kit/38cnsas"
            }
      ],
      
      updatesDTO: [
        { 
        dateOfUpdate:"28 Jan 2020",
        version: "Version 70.2",
        updateDescription: "<ul><li>Use breadcrumbs when the user is most likely to have landed on the page from an external source.</li></ul>"}]
    },
    {
      status:"03",
      capabilitiesId:2,
      pageTitle:"Portfolios",
      description: "description",
      userDetails: {
        userName:"test",
        tenantId:0
      },
    
      examplesDTO: [{
        previews:[{
        blockTitle: "block title",
        summdescription: "summ description",
        previewImages:[{
        previewImage:"image path"
        }
        ],
        codeSection:[{
          syntax: "CSS",
          code: "code"
         },
         {
          syntax: "CSS",
          code: "code"
         }],
        }   
        ],
        richTextBlock:[{
          blockTitle: "block titkle",
          richText:"<ul><li>Use breadcrumbs when the user is most likely to have landed on the page from an external source.</li></ul>",
        }]
      }],
      
      resourcesDTO: [
        {
        resourceName: "resName",
        linkLocation: "lonklocation"
        }
      ],
      
      updatesDTO: [
        { 
        dateOfUpdate:"date",
        version: "version",
        updateDescription: "update desc"}]
    },{
      status:"03",
      capabilitiesId:3,
      pageTitle:"Currency Allocation",
      description: "description",
      userDetails: {
        userName:"test",
        tenantId:0
      },
    
      examplesDTO: [{
        previews:[{
        blockTitle: "block title",
        summdescription: "summ description",
        previewImages:[{
        previewImage:"image path"
        }
        ],
        codeSection:[{
          syntax: "CSS",
          code: "code"
         },
         {
          syntax: "CSS",
          code: "code"
         }],
        }   
        ],
        richTextBlock:[{
          blockTitle: "block titkle",
          richText:"richtext",
        }]
      }],
      
      resourcesDTO: [
        {
        resourceName: "resName",
        linkLocation: "lonklocation"
        }
      ],
      
      updatesDTO: [
        { 
        dateOfUpdate:"date",
        version: "version",
        updateDescription: "update desc"}]
    }];

   // this.draftList =['Documents','Performance Graph']
   this.draftList=[
     {
    status:"01",
    capabilitiesId:4,
    pageTitle:"Documents",
    description: "description",
    userDetails: {
      userName:"test",
      tenantId:0
    },
  
    examplesDTO: [{
      previews:[{
      blockTitle: "block title",
      summdescription: "summ description",
      previewImages:[{
      previewImage:"image path"
      }
      ],
      codeSection:[{
        syntax: "CSS",
        code: "code"
       },
       {
        syntax: "CSS",
        code: "code"
       }],
      }   
      ],
      richTextBlock:[{
        blockTitle: "block titkle",
        richText:"richtext",
      }]
    }],
    
    resourcesDTO: [
      {
      resourceName: "resName",
      linkLocation: "lonklocation"
      }
    ],
    
    updatesDTO: [
      { 
      dateOfUpdate:"date",
      version: "version",
      updateDescription: "update desc"}]
  },{
    status:"01",
    capabilitiesId:5,
    pageTitle:"Performance Graph",
    description: "description",
    userDetails: {
      userName:"test",
      tenantId:0
    },
  
    examplesDTO: [{
      previews:[{
      blockTitle: "block title",
      summdescription: "summ description",
      previewImages:[{
      previewImage:"image path"
      }
      ],
      codeSection:[{
        syntax: "CSS",
        code: "code"
       },
       {
        syntax: "CSS",
        code: "code"
       }],
      }   
      ],
      richTextBlock:[{
        blockTitle: "block titkle",
        richText:"richtext",
      }]
    }],
    
    resourcesDTO: [
      {
      resourceName: "resName",
      linkLocation: "lonklocation"
      }
    ],
    
    updatesDTO: [
      { 
      dateOfUpdate:"date",
      version: "version",
      updateDescription: "update desc"}]
  }];

    this.forms = new FormGroup({
      previews: new FormArray([this.populatePreviewsArray()]),
      richTextBlock: new FormArray([this.populateRichTextArray()]),

    });

     this.form2 = new FormGroup({
      resources: new FormArray([this.populateResourcesArray()]),
     

    });
     this.form3 = new FormGroup({
       updates: new FormArray([this.populateUpdatesArray()]),

    });
    console.log(this.forms);
  }

  populatePreviewsArray(): FormGroup {
    return new FormGroup({
      blockTitle: new FormControl(""),
      summdescription: new FormControl(""),
      previewImages: new FormArray([this.populatePreviwImagesArray()]),
      codeSection: new FormArray([this.populateCodeSectionArray()]),
    });
  }

  setPreviews() {
    let control = <FormArray>this.forms.controls.previews;
    capabilitiesData.examplesDTO[0].previews.forEach(x => {
      control.push(this.fb.group({ 
        blockTitle: x['blockTitle'], 
        summdescription: x['summdescription'],
        previewImages: this.setPreviewImages(x['previewImages']),
        codeSection: this.setCodeSection(x['codeSection'])}))
    })
  }

  
  setPreviewImages(x) {
    let arr = new FormArray([])
    x.forEach(y => {
      arr.push(this.fb.group({ 
        previewImage: y['previewImage'] 
      }))
    })
    return arr;
  }
    
  setCodeSection(x) {
    let arr = new FormArray([])
    x.forEach(y => {
      arr.push(this.fb.group({ 
        syntax: y['syntax'],
        code: y['code'] 
      }))
    })
    return arr;
  }

  populatePreviwImagesArray(): FormGroup{
  return new FormGroup({
     previewImage: new FormControl("")
    });
  }

  populateCodeSectionArray(): FormGroup{
     return new FormGroup({
     syntax: new FormControl(""),
     code: new FormControl("")
    });
  }
  populateRichTextArray(): FormGroup{
     return new FormGroup({
     blockTitle: new FormControl(""),
     richText: new FormControl("")
    });
  }
populateResourcesArray(): FormGroup{
   return new FormGroup({
      resourceName: new FormControl(""),
      linkLocation: new FormControl(""),
     });
}
populateUpdatesArray(): FormGroup{
   return new FormGroup({
      dateOfUpdate: new FormControl(""),
      version: new FormControl(""),
      updateDescription: new FormControl(""),
     });
}
  // get examples() {
  //   return (this.forms.get("previews") as FormArray).controls;
  // }
   examples(): FormArray {
    return this.forms.get("previews") as FormArray
  }
   images(index:number) : FormArray {
    return this.examples().at(index).get("previewImages") as FormArray
  }
    codes(index:number) : FormArray {
    return this.examples().at(index).get("codeSection") as FormArray
  }
  richTxt(): FormArray {
    return this.forms.get("richTextBlock") as FormArray
  }
  resource(): FormArray {
    return this.form2.get("resources") as FormArray
  }
   update(): FormArray {
    return this.form3.get("updates") as FormArray
  }



  addPreviews() {
    let control = this.forms.get("previews") as FormArray;
    control.push(this.populatePreviewsArray());
  }
  addRichText() {
    let control = this.forms.get("richTextBlock") as FormArray;
    control.push(this.populateRichTextArray());
  }
   addCode(i) {
    let control = this.examples().at(i).get("codeSection") as FormArray;
    control.push(this.populateCodeSectionArray());
  }
  addResources() {
    let control = this.form2.get("resources") as FormArray;
    control.push(this.populateResourcesArray());
  }
  addUpdates() {
    let control = this.form3.get("updates") as FormArray;
    control.push(this.populateUpdatesArray());
  }

  removePreviews(i) {
    let control = this.forms.get("previews") as FormArray;
    control.removeAt(i);
  }
   removeCode(i,codeIdx) {
    let control =  this.examples().at(i).get("codeSection") as FormArray;
    control.removeAt(codeIdx);
  }
  removeRichText(i){
    let control = this.forms.get("richTextBlock") as FormArray;
    control.removeAt(i);
  }
   removeResources(i){
    let control = this.form2.get("resources") as FormArray;
    control.removeAt(i);
  }
   removeUpdates(i){
    let control = this.form3.get("updates") as FormArray;
    control.removeAt(i);
  }

  closeExamplesAddBlock() {
  this.showExamplesAddBlock=false;
  }
  closeResourcesAddBlock() {
    this.showResourcesAddBlock=false;
    }
    closeUpdatesAddBlock() {
      this.showUpdatesAddBlock=false;
      }
  onStatusChange(event){
    this.status=event.target.value;
    if(this.status =='draft'){
      console.log("coming form changes");
      this.forms = new FormGroup({
        previews: new FormArray([]),
        richTextBlock: new FormArray([this.populateRichTextArray()]),
  
      });
  
       this.form2 = new FormGroup({
        resources: new FormArray([this.populateResourcesArray()]),
       
  
      });
       this.form3 = new FormGroup({
         updates: new FormArray([this.populateUpdatesArray()]),
  
      });
    }
    this.setPreviews();
  }
  getCapabilities() {
    let data=''
    this.capabilityService.getAllCapabilities(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.capabilitiesArray = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  getByID() {
    let data=''
    this.capabilityService.getCapabilityByID(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.capabilitiesArray = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  getApprovedList() {
    let data='03'
    this.capabilityService.getCapabilityByStatus(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.approvedList = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }
  getDraftList() {
    let data='01'
    this.capabilityService.getCapabilityByStatus(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.draftList = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  makerAction(btnAction){

let model = {
  status:"01",
  capabilityId:0,
  pagetitle: {
    label: "Page Title",
    value: this.pageTitle,
    type: "text"
  },
  description: {
    label: "Description",
    value: this.description,
    type: "text"
  },
  userDetails: {
    userName:"test",
    tenentId:this.capabilityService.getSelectedMenuItem().tenantId
  },
  comments:{
    userName:"test",
    comment:"",
    inptDttm:""
  },

  examplesDTO: [],
  resourcesDTO: [],
  updatesDTO: []

};
 
  model['examplesDTO'] = [this.examplesFormToModel()];
  model['resourcesDTO'] = [this.resourcesFormToModel()];
  model['updatesDTO'] = [this.updatesFormToModel()];
  if(btnAction == 'save'){
    model.status ="01"
  }
  else if(btnAction == 'submit'){
    model.status ="02"
  }

  // this.subscriptions.push(
    this.capabilityService.makerAction(model).subscribe(
      res => {
        this.toastNotificationService.showSuccess(
        btnAction == "save"?'Data saved as draft':'Capability submitted for approval'
        );
        this.route.navigate(['/CSDigital']);
      },
      (error: HttpErrorResponse) => {
        throw new Error(error.error.message);
      }
    )
  //);

  console.log("my model",model);
  }

  examplesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.examplesDTO[0]);
    let formData = this.forms.getRawValue();
      for (let key in formData) {
      if (modelData.hasOwnProperty(key))
       modelData[key] = formData[key] || '';
      }
          
      
     
   console.log("modelData",modelData);
    return modelData;
  };

  resourcesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.resourcesDTO[0]);
    let formData = this.form2.getRawValue();
      for (let key in formData) {
      if (modelData.hasOwnProperty(key))
        modelData[key] = formData[key] || '';
    };
   console.log("modelData",modelData);
    return modelData;
  };

  updatesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.updatesDTO[0]);
    let formData = this.form3.getRawValue();
      for (let key in formData) {
      if (modelData.hasOwnProperty(key))
        modelData[key] = formData[key] || '';
    };
   console.log("modelData",modelData);
    return modelData;
  };
  
  onFileChange(event){
    console.log("img url",event.target.files);
      if (event.target.files[0].type == "image/jpeg" || event.target.files[0].type == "image/jpg" || event.target.files[0].type == "image/png") {
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]); // read file as data url
        reader.onload = (event) => { // called once readAsDataURL is completed 
          let imgArray = reader.result;
          console.log("img url",imgArray);
          //this.imgWidth = '400px'; 
          //this.imgHeight = '100px';
      
        }
      }
    
    
  }

  onSubmit() {
    console.log(this.forms.getRawValue());
     console.log(this.form2.getRawValue());
      console.log(this.form3.getRawValue());
      this.makerAction('submit');
  }

  public ngOnDestroy(): void {
    this.onDestroy$.next();
    this.onDestroy$.complete();

  }
  
}
