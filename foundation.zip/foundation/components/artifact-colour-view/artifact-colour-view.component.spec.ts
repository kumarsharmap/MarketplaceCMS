import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtifactColourViewComponent } from './artifact-colour-view.component';

describe('ArtifactColourViewComponent', () => {
  let component: ArtifactColourViewComponent;
  let fixture: ComponentFixture<ArtifactColourViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArtifactColourViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtifactColourViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
