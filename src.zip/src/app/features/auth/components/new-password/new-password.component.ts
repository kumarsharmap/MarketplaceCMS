import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { ParentSubscriptionComponent } from 'src/app/core/components/parent-subscription/parent-subscription.component';
import { LoginService } from '../../services/login/login.service';
import { RegisterService } from '../../services/regsiter/register.service';

@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.css'],
})
export class NewPasswordComponent
  extends ParentSubscriptionComponent
  implements OnInit {
  newPasswordForm: FormGroup;
  userEmailName: string;

  constructor(
    private router: Router,
    private registerService: RegisterService,
    private loginService: LoginService
  ) {
    super();
  }

  ngOnInit(): void {
    this.createNewPasswordForm();
    this.getEmail();
  }

  public onPasswordChanged() {
    const email = this.userEmailName;
    const forgotWordValue = { ...this.newPasswordForm.value, email };
    this.subscriptions.push(
      this.registerService
        .changePassword(forgotWordValue)
        .pipe(take(1))
        .subscribe(
          () => {
            this.router.navigate(['/']);
          },
          (error: HttpErrorResponse) => {
            throw new Error(error.error.message);
          }
        )
    );
  }

  private getEmail() {
    this.userEmailName = this.loginService.getLoginEmail();
    this.newPasswordForm.get('email').setValue(this.userEmailName);
    this.newPasswordForm.get('email').disable();
  }

  private createNewPasswordForm(): void {
    this.newPasswordForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', Validators.required),
      newPassword: new FormControl('', Validators.required),
    });
  }
}
