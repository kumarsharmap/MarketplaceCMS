import { Component, OnInit, ElementRef, EventEmitter, ViewChild, AfterViewInit, Output } from '@angular/core';
import { FormGroup, FormArray, FormControl, FormBuilder } from '@angular/forms';
import { capabilitiesData } from '../capabilities/capabilities.model';

@Component({
  selector: 'app-capabilities-resources',
  templateUrl: './capabilities-resources.component.html',
  styleUrls: ['./capabilities-resources.component.css']
})
export class CapabilitiesResourcesComponent implements OnInit  {
 
  resourcesForm:FormGroup;
  showResourcesAddBlock: boolean = true;
  constructor(private fb:FormBuilder) {
  } 
  

  
  ngOnInit(): void {
    this.resourcesForm = this.fb.group({
      resources: new FormArray([this.populateResourcesArray()]),


    });
  }
 
  /** convenience getter for easy access to form fields
   * @method resource
   * @return FormArray
   */
  resource(): FormArray {
    return this.resourcesForm.get("resources") as FormArray
  }

  /** To populate formgroup with form controls
   * @method populateResourcesArray
   * @return FormGroup
   */
  populateResourcesArray(): FormGroup {
    return new FormGroup({
      resourceName: new FormControl(""),
      linkLocation: new FormControl(""),
    });
  }

  /** method to add/push new form control
   * @method addResources
   * @return void
   */
  addResources() {
    let control = this.resourcesForm.get("resources") as FormArray;
    control.push(this.populateResourcesArray());
  }

  /** method to remove/delete  form controls
  * @method removeResources
  * @return void
  */
  removeResources(i) {
    let control = this.resourcesForm.get("resources") as FormArray;
    control.removeAt(i);
  }

  resourcesFormToModel() {
    let modelData = Object.assign({}, capabilitiesData.resourcesDTO[0]);
    let formData = this.resourcesForm.value;
    console.log("formdata",formData);
    return formData;
  //     for (let key in formData) {
  //     if (modelData.hasOwnProperty(key))
  //       modelData[key] = formData[key] || '';
  //   };
  //  console.log("modelData",modelData);
  //   return modelData;
  };
  // formData(){
  //   this.resourcesFormToModel();
  // }
  closeResourcesAddBlock() {
    this.showResourcesAddBlock=false;
    }
}
