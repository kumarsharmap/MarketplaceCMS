import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FoundationService } from '../services/foundation.service';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
@Component({
  selector: 'app-foundation-home',
  templateUrl: './foundation-home.component.html',
  styleUrls: ['./foundation-home.component.css']
})
export class FoundationHomeComponent implements OnInit {
  listOfFoundationArtifacts: any;

  constructor(public foundationServ: FoundationService, private toastNotificationService: ToastNotificationService) { }

  ngOnInit(): void {
    //Need to remove this after integration
    this.listOfFoundationArtifacts = [
      {
        "foundationId": 0,
        "pageTitle": "colours",
        "pageDescription": "colours component",
        "artifactType": "colour"
      },
      {
        "foundationId": 0,
        "pageTitle": "Grid",
        "pageDescription": "Grid component",
        "artifactType": "others"
      },
    ];

    this.foundationServ.getAllFoundations().subscribe(
      response => {
        console.log("API success");
        this.listOfFoundationArtifacts = response;
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed fetch list of artifacts");
      })

  }

}
