export class ApprovalQueueModel {
  artifactId: number;
  artifactTitle: string;
  artifactDescription: string;
  tenantId: number;
  tenantName: string;
  artifactCategory: string;
  createdBy: string;
  createdOn: Date;
  lastModifiedOn: Date;
  status: string;
  active: boolean;
}
