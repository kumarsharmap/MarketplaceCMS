import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { ApprovalQueueComponent } from './components/approval-queue/approval-queue.component';
import { PageManagementComponent } from './components/page-management/page-management.component';
import { SelectTenantComponent } from './components/select-tenant/select-tenant.component';
import { SelectedTenantListComponent } from './components/selected-tenant-list/selected-tenant-list.component';


@NgModule({
  declarations: [ApprovalQueueComponent, PageManagementComponent, SelectTenantComponent, SelectedTenantListComponent],
  imports: [
    CommonModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
