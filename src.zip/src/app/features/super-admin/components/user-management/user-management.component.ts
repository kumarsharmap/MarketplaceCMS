import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParentSubscriptionComponent } from 'src/app/core/components/parent-subscription/parent-subscription.component';
import { UserManagementModel } from 'src/app/core/models/user-management.model';
import { UserManagementService } from '../../services/user-management/user-management.service';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css'],
})
export class UserManagementComponent
  extends ParentSubscriptionComponent
  implements OnInit {
  userManagement: UserManagementModel[];

  constructor(
    private userManagementService: UserManagementService,
    private router: Router
  ) {
    super();
  }

  ngOnInit(): void {
    this.getUserManagement();
  }

  public navigateToCreateUser(): void {
    this.router.navigate(['/createuser']);
  }

  public navigateToManage(usermanagement: UserManagementModel): void {
    this.userManagementService.getUserById(usermanagement.userId);
  }

  private getUserManagement(): void {
    this.userManagementService
      .getAllUserManagement()
      .subscribe((getAllUsers) => {
        this.userManagement = getAllUsers;
      });
  }
}
