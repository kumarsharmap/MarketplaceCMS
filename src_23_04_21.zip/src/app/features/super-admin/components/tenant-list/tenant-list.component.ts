import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LoginResponse } from 'src/app/core/models/header-menu.model';
import { CreateLoginRequest } from 'src/app/core/models/login.model';
import { CreateTenantModel } from 'src/app/core/models/tenant.model';
import { MenuService } from 'src/app/core/services/menu/menu.service';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { ConfirmWindowComponent } from 'src/app/shared/components/confirm-window/confirm-window.component';
import { TenantService } from '../../services/tenant/tenant.service';

@Component({
  selector: 'app-tenant-list',
  templateUrl: './tenant-list.component.html',
  styleUrls: ['./tenant-list.component.css'],
})
export class TenantListComponent implements OnInit {
  @ViewChild(ConfirmWindowComponent)
  confirmWindowComponent: ConfirmWindowComponent;
  tenantData: CreateTenantModel[];
  deleteTenant: CreateTenantModel;
  menuData: any;
  userId: number;

  constructor(
    private router: Router,
    private tenantService: TenantService,
    private loginService: LoginService,
    private menuService: MenuService
  ) {}

  ngOnInit(): void {
    this.getTenant();
    this.loginService.authentication$.subscribe((data: LoginResponse[]) => {
      if (data) {
        this.userId = data[0].userId;
      }
    });
  }

  public onTenantEdit(tenant: CreateTenantModel): void {
    this.tenantService.setTenantData(tenant);
    this.router.navigate(['createTenant']);
  }

  public onClickCreateTenant(): void {
    this.router.navigate(['createTenant']);
  }

  public onDeleteCheckbox(event: Event, id: number): void {
    if ((event.target as HTMLInputElement).checked && this.tenantData) {
      this.deleteTenant = this.tenantData.find(
        (item: CreateTenantModel) => item.tenantId === id
      );
    } else {
      delete this.deleteTenant;
    }
  }

  public onDeleteTenant(): void {
    if (this.deleteTenant) {
      this.confirmWindowComponent.openModal();
    }
  }

  public onClickYes(): void {
    this.tenantService
      .removeTenant(this.deleteTenant.tenantId)
      .subscribe(() => {
        this.getTenant();
        this.referMenu();
        delete this.deleteTenant;
      });
  }

  public onClickNo(): void {}

  public referMenu() {
    const loginData: CreateLoginRequest = {
      email: this.loginService.getLoginEmail(),
      password: this.loginService.getLoginPassword(),
    };
    this.loginService.loginUser(loginData, false);
  }

  private getTenant(): void {
    if (this.loginService.getSuperAdmin()) {
      this.getAllTenantList();
    } else {
      this.getTenantByAdmin();
    }
  }

  private getTenantByAdmin(): void {
    this.tenantService.getTenantByAdmin(this.userId).subscribe(
      (data) => {
        this.tenantData = data;
      },
      (error) => {
        throw new Error(error.error.message);
      }
    );
  }

  private getAllTenantList(): void {
    this.tenantService.getTenant().subscribe(
      (data) => {
        this.tenantData = data;
      },
      (error) => {
        throw new Error(error.error.message);
      }
    );
  }
}
