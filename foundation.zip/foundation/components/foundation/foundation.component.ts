import { Component, OnInit } from '@angular/core';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
import { FoundationService } from '../services/foundation.service';

@Component({
  selector: 'app-foundation',
  templateUrl: './foundation.component.html',
  styleUrls: ['./foundation.component.css']
})
export class FoundationComponent implements OnInit {
  listOfFoundationArtifacts: any = [];
  homeFoundationFlag: boolean = false;
  createFoundationFlag: boolean = false;
  foundationFlag: boolean = false;
  clicked: any;
  idToSend: any = "";
  constructor(public foundationServ: FoundationService, private toastNotificationService: ToastNotificationService) { }

  ngOnInit(): void {
    this.loadHome();
    //Need to remove this after integration
    this.listOfFoundationArtifacts = [
      {
        "foundationId": 0,
        "pageTitle": "colours",
        "pageDescription": "colours component",
        "artifactType": "colour"
      },
      {
        "foundationId": 0,
        "pageTitle": "Grid",
        "pageDescription": "Grid component",
        "artifactType": "others"
      },
    ];
    this.foundationServ.getAllFoundations().subscribe(
      response => {
        console.log("API success");
        this.listOfFoundationArtifacts = response;
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed fetch list of artifacts");
      })

  }
  loadData(obj) {
    this.clicked = obj;
    if (obj.artifactType == "colour") {
      this.idToSend = obj.foundationId;
      this.homeFoundationFlag = false;
      this.createFoundationFlag = false;
      this.foundationFlag = true;
    }
  }

  loadHome() {
    this.homeFoundationFlag = true;
    this.foundationFlag = false;
    this.createFoundationFlag = false;
  }

  loadCreate() {
    this.foundationFlag = false;
    this.homeFoundationFlag = false;
    this.createFoundationFlag = true;
  }
}
