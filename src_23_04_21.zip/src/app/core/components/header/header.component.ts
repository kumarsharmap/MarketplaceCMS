import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { NavigationDropdownDirective } from '../../directives/drop-down/navigation-dropdown.directive';
import { LoginResponse } from '../../models/header-menu.model';
import { MenuService } from '../../services/menu/menu.service';
import { ParentSubscriptionComponent } from '../parent-subscription/parent-subscription.component';
import { CapabilitiesService } from 'src/app/features/capabilities/components/capabilities/capabilities.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent
  extends ParentSubscriptionComponent
  implements OnInit {
  isOpen: boolean;
  headerMenuItems: LoginResponse[] = [];
  constructor(
    private router: Router,
    private loginService: LoginService,
    private menu: MenuService,
    public capabilityService:CapabilitiesService
  ) {
    super();
  }

  ngOnInit(): void {
    this.createHeaderMenu();
  }

  private createHeaderMenu() {
    this.subscriptions.push(
      this.loginService.authentication$.subscribe(
        (menuItem: LoginResponse[]) => {
          if (menuItem) {
            this.headerMenuItems = menuItem;
          }
        }
      )
    );
  }

  public navigateToDashboard() {
    this.menu.menu$.next(null);
    this.router.navigate(['/landing']);
  }

  public navigateToSignOut() {
    this.loginService.authentication$.next(null);
    this.menu.menu$.next(null);
    this.router.navigate(['/']);
  }

  public navigateToCommonMenu() {
    this.router.navigate(['CSDigital']);
  }

  public navigateToMenu(menu) {
    const setMenuItem: string = menu.tenantName.toString();
    this.menu.menu$.next(menu);
    // this.router.navigate([setMenuItem.replace(/ /g, '')]);
    // let navigationExtras: NavigationExtras = {
    //   queryParams: {
    //     "tenantName":  menu.tenantName.toString()
    //   }
    // };
    this.capabilityService.setSelectedMenuItem(menu);
    this.router.navigate(['CSDigital']);
  }
}

