import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { PermissionModel } from 'src/app/core/models/permission.model';
import { ConfirmWindowComponent } from 'src/app/shared/components/confirm-window/confirm-window.component';
import { PermissionService } from '../../services/permissoin/permission.service';
import { AddPermissionComponent } from '../add-permission/add-permission.component';

@Component({
  selector: 'app-permission',
  templateUrl: './permission.component.html',
  styleUrls: ['./permission.component.css'],
})
export class PermissionComponent implements OnInit {
  @ViewChild(AddPermissionComponent)
  addPermissionModalComponent: AddPermissionComponent;
  @ViewChild(ConfirmWindowComponent)
  confirmWindowComponent: ConfirmWindowComponent;
  permissionData: PermissionModel[];
  deletePermission: PermissionModel;

  constructor(
    private permissionService: PermissionService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getPermissionData();
  }

  onOpenModal(): void {
    this.addPermissionModalComponent.openModal();
  }

  public onPermissionEdit(permission): void {
    this.addPermissionModalComponent.openPermissionModalEdit(permission);
  }

  public onDeleteCheckbox(event: Event, id: number): void {
    this.deletePermission = this.permissionData.find(
      (item: PermissionModel) => item.permissionId === id
    );
  }

  public onDeletePermission(): void {
    if (this.deletePermission) {
      this.confirmWindowComponent.openModal();
    }
  }

  public onClickYes(): void {
    this.permissionService
      .removePermission(this.deletePermission.permissionId)
      .subscribe(() => {
        this.getPermissionData();
      });
  }

  public onClickNo(): void {}

  public onLogOut(): void {
    this.router.navigate(['/']);
  }

  public getPermissionData(): void {
    this.permissionService.getPermission().subscribe((data) => {
      this.permissionData = data;
    });
  }
}
