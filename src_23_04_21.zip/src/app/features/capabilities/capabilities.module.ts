import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CapabilitiesRoutingModule } from './capabilities-routing.module';
import { CapabilitiesComponent } from './components/capabilities/capabilities.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreModule } from 'src/app/core/core.module';

import { TabsModule } from 'ngx-bootstrap/tabs';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CapabilitiesViewComponent } from './components/capabilities-view/capabilities-view.component';
import { QuillModule } from 'ngx-quill'


@NgModule({
  declarations: [CapabilitiesComponent, CapabilitiesViewComponent],
  imports: [ TabsModule.forRoot(), CommonModule,CapabilitiesRoutingModule, QuillModule,CoreModule, SharedModule,ReactiveFormsModule,FormsModule],
  bootstrap: [CapabilitiesComponent]
})
export class CapabilitiesModule {}
