import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/features/auth/services/login/login.service';

@Component({
  selector: 'app-hello-marketplace',
  templateUrl: './hello-marketplace.component.html',
  styleUrls: ['./hello-marketplace.component.css'],
})
export class HelloMarketplaceComponent implements OnInit {
  userName: string;
  constructor(private loginService: LoginService) {}

  ngOnInit(): void {
    this.loginService.authentication$.subscribe((item) => {
      if (item) {
        this.userName = item[0].name;
      }
    });
  }
}
