import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CapabilitiesRoutingModule } from './capabilities-routing.module';
import { CapabilitiesComponent } from './components/capabilities/capabilities.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreModule } from 'src/app/core/core.module';

import { TabsModule } from 'ngx-bootstrap/tabs';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CapabilitiesViewComponent } from './components/capabilities-view/capabilities-view.component';
import { QuillModule } from 'ngx-quill';
import { CapabilitiesHomeComponent } from './components/capabilities-home/capabilities-home.component';
import { CapabilitiesTechnicalSummaryComponent } from './components/capabilities-technical-summary/capabilities-technical-summary.component';
import { CapabilitiesResourcesComponent } from './components/capabilities-resources/capabilities-resources.component';
import { CapabilitiesUpdatesComponent } from './components/capabilities-updates/capabilities-updates.component'


@NgModule({
  declarations: [CapabilitiesComponent, CapabilitiesViewComponent, CapabilitiesHomeComponent, CapabilitiesTechnicalSummaryComponent, CapabilitiesResourcesComponent, CapabilitiesUpdatesComponent],
  imports: [ TabsModule.forRoot(), CommonModule,CapabilitiesRoutingModule, QuillModule,CoreModule, SharedModule,ReactiveFormsModule,FormsModule],
  bootstrap: [CapabilitiesComponent]
})
export class CapabilitiesModule {}
