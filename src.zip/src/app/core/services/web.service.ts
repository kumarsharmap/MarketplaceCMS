
import { Router } from "@angular/router";

import { Observable, throwError } from "rxjs";
import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse
} from "@angular/common/http";
import { tap, map, catchError, finalize, timeout, delay } from "rxjs/operators";
// import { environment } from "@env/environment";
import {CORE_CONSTANTS} from "../core.constants";

@Injectable({
  providedIn: "root"
})
export class WebService {
  /**
   * @method constructor
   * @param http
   * @param spinner
   */
  constructor(
    private http: HttpClient,
    //private httpOption:HttpHeaders,
       private router: Router
  ) {}

  /**
   * @method postRequest
   * @param url
   * @param data
   * Request for update complete information with full payload
   */
  public postRequestForProdCode(url, data): Observable<any> {
 
    return this.http.post(url, data).pipe(
  
      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }
 /**
   * @method postRequest
   * @param url
   * @param data
   * Request for update complete information with full payload
   */
  public postRequest(url, data, httpOption?): Observable<any> {

    return this.http.post(url, data, httpOption).pipe(
  
      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }

  /**
   * @method getRequest
   * @param url
   * Request for get the information
   */
  public getRequest(url, http?): Observable<any> {
 
    return this.http.get<any>(url, http).pipe(
    
      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );  
  }

  public getRequestLogout(url, http?): Observable<any> {

    return this.http.get<any>(url, http).pipe(
 
      timeout(5000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );  
  }


  /**
   * @method deleteRequest
   * @param url
   * Request for delete information
   */
  public deleteRequest(url, http?) {

    return this.http.delete<any>(url, http).pipe(
 
      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }

  /**
   * @method patchRequest
   * @param url
   * @param requestData
   * Request for update only required information
   */
  public patchRequest(url, data, httpOption?): Observable<any> {
 
    return this.http.patch(url, data, httpOption).pipe(
    
      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }

  /**
   * @method putRequest
   * @param url
   * @param data
   * Reuest to change the state of a infornation
   */
  public putRequest(url, data): Observable<any> {

    return this.http.put(url, data).pipe(

      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }
  
  /**
   * @method putRequestUrl
   * @param url
   * Request for update the information without argument
   */
  public putRequestUrl(url, http?): Observable<any> {

    return this.http.put<any>(url, http).pipe(

      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );  
  }

  /**
   * @method getRequestParams
   * @param url
   * Request for get the information
   */
  public getRequestParams(url,params, http?): Observable<any> {

    return this.http.get<any>(url,{params:params}).pipe(

      timeout(100000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }

   /**
   * @method deleteRequestParams
   * @param url
   * Request for delete information
   */
  public deleteRequestParams(url,params, http?) {

    return this.http.delete<any>(url,{params:params}).pipe(

      timeout(30000),
      catchError((err: HttpErrorResponse) => {
        return this.handleError(err);
      })
    );
  }

  /**
   * @method handleError
   * @param error
   * This method is called to handle Error
   */
  private handleError(error: HttpErrorResponse): Observable<any> {

    if (error) {
       if (error.status === 404) {
        return throwError(error.statusText);
      } 
      if (error.status === 500) {
        if(error.error.error === "Internal Server Error"){
          return throwError("Unexpected Error Occured");
        }else{
          return throwError(error.error.message);
        }        
      }
      if (error.status === 401) {
        return throwError(error.error);
      }
      if(error.message === 'Timeout has occurred'){
        this.router.navigate(['/login']);
      }
      if(error) { 
        return throwError(error.error);
      }
    }
  }

  
  public error(message = CORE_CONSTANTS.ERROR_OCCUR) {
    if (message && message.includes(CORE_CONSTANTS.WEBPACK)) {
      return;
    }
    message =
      message == CORE_CONSTANTS.CANNOT_READ
        ? CORE_CONSTANTS.SERVER
        : message;
   
  }
  
  public success(message = CORE_CONSTANTS.OPERATION) {
   
  }
 
  public warning(message = CORE_CONSTANTS.ERROR_OCCUR) {
    message =
      message == CORE_CONSTANTS.CANNOT_READ
        ? CORE_CONSTANTS.SERVER
        : message;
  
  }
}
