export class CreateTenantModel {
  tenantId: number;
  artifactTitle: string;
  tenantName: string;
  tenantDescription: string;
  tenantUser: CreateTenantAddUserModel[];
  artifactCategory: string;
  selectLocation: boolean[];
}

export class CreateTenantAddUserModel {
  userId: number;
  email: string;
  roleId: number;
  roleName: string;
  name?: string;
  tenantId?: number;
}
