import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ConfirmWindowComponent } from './components/confirm-window/confirm-window.component';
import { RichTextTemplateComponent } from './components/rich-text-template/rich-text-template.component';
import { QuillModule } from 'ngx-quill';
import { ReactiveFormsModule } from '@angular/forms';
import { ViewRichTextTemplateComponent } from './components/view-rich-text-template/view-rich-text-template.component';

@NgModule({
  declarations: [ConfirmWindowComponent, RichTextTemplateComponent, ViewRichTextTemplateComponent],
  imports: [CommonModule, RouterModule, QuillModule.forRoot(), ReactiveFormsModule,],
  exports: [ConfirmWindowComponent, RichTextTemplateComponent, ViewRichTextTemplateComponent],
})
export class SharedModule { }
