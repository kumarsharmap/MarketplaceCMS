export const CORE_CONSTANTS = {
    
    ALPHANUMERIC_EXP:"^[0-9]+$",
    USER_BRANCH:"userBranch",
    CURRENT_USER:"currentUser",
    INVALID_CRED:"Invalid credentials, please enter correct details.",
    INPUT:"Input",
    CONTROL:"Control",
    SESSION_EXPIRED:"Session Expired. Please re-login to continue!",
    ERROR_OCCUR:"Some error occurred",
    WEBPACK:"WEBPACK_IMPORTED_MODULE",
    CANNOT_READ:"Cannot read property 'stop' of undefined",
    SERVER:"Server inaccessible",
    ERROR:"error",
    ERROR_MESSAGE:"Error Message",
    OPERATION:"Operation completed successfully",
    SUCCESS:"success",
    SUCCESS_MSG:"Success Message",
    WARN:"warn",
    WARNING_MSG:"Warning Message",
    ACCOUNTCONTROLLEDDATA: 'controlled',
    TECHNICAL_ERROR: "Technical Error: System Down Time",
    SERVER_FAILURE: "Http failure response"
};

export const LOGIN_CONSTANT=JSON.parse(sessionStorage.getItem('currentUser'));