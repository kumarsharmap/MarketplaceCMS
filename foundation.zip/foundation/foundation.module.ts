import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FoundationHomeComponent } from './components/foundation-home/foundation-home.component';
import { FoundationRoutingModule } from './foundation-routing.module';
import { FoundationComponent } from './components/foundation/foundation.component';
import { CreateFoundationComponent } from './components/create-foundation/create-foundation.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ArtifactColourViewComponent } from './components/artifact-colour-view/artifact-colour-view.component';


@NgModule({
  declarations: [FoundationHomeComponent, FoundationComponent, CreateFoundationComponent, ArtifactColourViewComponent],
  imports: [
    CommonModule,
    FoundationRoutingModule,
    ReactiveFormsModule
  ]
})
export class FoundationModule { }
