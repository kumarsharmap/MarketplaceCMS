import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FoundationHomeComponent } from './components/foundation-home/foundation-home.component';
import { FoundationRoutingModule } from './foundation-routing.module';
import { FoundationComponent } from './components/foundation/foundation.component';
import { CreateFoundationComponent } from './components/create-foundation/create-foundation.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ArtifactColourViewComponent } from './components/artifact-colour-view/artifact-colour-view.component';
import { QuillModule } from 'ngx-quill';
import { RichTextTemplateComponent } from 'src/app/shared/components/rich-text-template/rich-text-template.component';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [FoundationHomeComponent, FoundationComponent, CreateFoundationComponent, ArtifactColourViewComponent],
  imports: [
    CommonModule,
    FoundationRoutingModule,
    ReactiveFormsModule,
    SharedModule,
    QuillModule

  ],

})
export class FoundationModule { }
