import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-capability-updates',
  templateUrl: './latest-capability-updates.component.html',
  styleUrls: ['./latest-capability-updates.component.css']
})
export class LatestCapabilityUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
