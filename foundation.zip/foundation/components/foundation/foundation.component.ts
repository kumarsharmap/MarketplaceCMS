import { Component, OnInit } from '@angular/core';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';
import { FoundationService } from '../services/foundation.service';
import { RichTextTemplateComponent } from 'src/app/shared/components/rich-text-template/rich-text-template.component';
@Component({
  selector: 'app-foundation',
  templateUrl: './foundation.component.html',
  styleUrls: ['./foundation.component.css']
})
export class FoundationComponent implements OnInit {
  listOfApprovedFoundationArtifacts: any = [];
  listOfDraftFoundationArtifacts: any = [];
  homeFoundationFlag: boolean = false;
  createFoundationFlag: boolean = false;
  foundationFlag: boolean = false;
  othersFoundationFlag: boolean = false;
  viewOtherArtifactFlag: boolean = false;
  clicked: any;
  idToSend: any = "";
  statusFlag: string = "";
  inpObjTosend: any = {};
  richTextTemplateInput: any;

  constructor(public foundationServ: FoundationService, private toastNotificationService: ToastNotificationService) { }

  ngOnInit(): void {
    this.loadHome();
    this.onStatusChange('approved');

  }
  fetchListOfApproved() {
    this.foundationServ.getArtifactsByStatus("Approved").subscribe(
      response => {
        console.log("API success");
        this.listOfApprovedFoundationArtifacts = response;
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed fetch list of  approved artifacts");
      })
  }
  fetchListOfDraft() {
    this.foundationServ.getArtifactsByStatus("Draft").subscribe(
      response => {
        console.log("API success");
        this.listOfDraftFoundationArtifacts = response;
      },
      (error) => {
        console.log("API fail");
        this.toastNotificationService.showError("Failed fetch list of  draft artifacts");
      })
  }
  onStatusChange(event) {
    console.log("event", event);
    if (event == 'draft') {
      this.statusFlag = "draft";
      console.log("event1", event);
      this.listOfDraftFoundationArtifacts = [
        {
          "foundationId": 0,
          "pageTitle": "Primary",
          "pageDescription": "Primary component",
          "artifactType": "colour"
        },
        {
          "foundationId": 0,
          "pageTitle": "Secondary",
          "pageDescription": "Secondary component",
          "artifactType": "others"
        },
      ];
      this.fetchListOfApproved();
    } else if (event == 'approved') {
      this.statusFlag = "approved";
      console.log("event2", event);
      this.listOfApprovedFoundationArtifacts = [
        {
          "foundationId": 0,
          "pageTitle": "colours",
          "pageDescription": "colours component",
          "artifactType": "colour"
        },
        {
          "foundationId": 0,
          "pageTitle": "Grid",
          "pageDescription": "Grid component",
          "artifactType": "others"
        },
      ];
      this.fetchListOfDraft();
    }
  }
  loadData(status, obj) {
    this.clicked = obj;
    if (status == 'approved') {
      if (obj.artifactType == "colour") {
        this.idToSend = obj.foundationId;
        this.homeFoundationFlag = false;
        this.createFoundationFlag = false;
        this.othersFoundationFlag = false;
        this.viewOtherArtifactFlag = false;
        this.foundationFlag = true;

      } else if (obj.artifactType == "others") {
        this.homeFoundationFlag = false;
        this.createFoundationFlag = false;
        this.othersFoundationFlag = false;
        this.viewOtherArtifactFlag = true;
        this.idToSend = obj.foundationId;

      }
    } else if (status == 'draft') {
      if (obj.artifactType == "colour") {
        this.inpObjTosend = {
          type: "Edit",
          detailsObj: obj
        }
        this.foundationFlag = false;
        this.homeFoundationFlag = false;
        this.othersFoundationFlag = false;
        this.viewOtherArtifactFlag = false;
        this.createFoundationFlag = true;

        this.clicked = {};
      } else if (obj.artifactType == "others") {
        this.richTextTemplateInput = {
          artifactType: "Foundation",
          type: "Edit",
          details: obj
        }
        this.viewOtherArtifactFlag = false;
        this.homeFoundationFlag = false;
        this.createFoundationFlag = false;
        this.foundationFlag = false;
        this.othersFoundationFlag = true;
      }
    }

  }

  loadHome() {
    this.idToSend = {};
    this.foundationFlag = false;
    this.createFoundationFlag = false;
    this.othersFoundationFlag = false;
    this.viewOtherArtifactFlag = false;
    this.homeFoundationFlag = true;
    this.clicked = {};

  }

  loadCreate() {
    this.idToSend = {};
    this.inpObjTosend = {
      type: "Create",
      detailsObj: {}
    }
    this.foundationFlag = false;
    this.homeFoundationFlag = false;
    this.othersFoundationFlag = false;
    this.viewOtherArtifactFlag = false;
    this.createFoundationFlag = true;
    this.clicked = {};
  }
  loadOthers() {
    this.richTextTemplateInput = {
      artifactType: "Foundation",
      type: "Create",
      details: {}
    }
    this.foundationFlag = false;
    this.homeFoundationFlag = false;
    this.createFoundationFlag = false;
    this.viewOtherArtifactFlag = false;
    this.othersFoundationFlag = true;

  }
}
