import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { AuthModule } from './features/auth/auth.module';
import { SuperAdminModule } from './features/super-admin/super-admin.module';
import { CapabilitiesModule } from './features/capabilities/capabilities.module';
import { AdminModule } from './features/admin/admin.module';
import { TabsModule } from 'ngx-bootstrap/tabs';


@NgModule({
  declarations: [AppComponent],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    CoreModule.forRoot(),
    SharedModule,
    AuthModule.forRoot(),
    SuperAdminModule,
    AdminModule,
    CapabilitiesModule,
    TabsModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
