import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateNewUserComponent } from './components/create-new-user/create-new-user.component';
import { CreateTenantComponent } from './components/create-tenant/create-tenant.component';
import { ManageUserManagementComponent } from './components/manage-user-management/manage-user-management.component';
import { PermissionComponent } from './components/permission/permission.component';
import { RolesComponent } from './components/roles/roles.component';
import { TenantListComponent } from './components/tenant-list/tenant-list.component';
import { UserManagementComponent } from './components/user-management/user-management.component';

const routes: Routes = [
  {
    path: '',
    component: TenantListComponent,
  },
  {
    path: 'createTenant',
    component: CreateTenantComponent,
  },
  {
    path: 'user',
    component: UserManagementComponent,
  },
  {
    path: 'manage',
    component: ManageUserManagementComponent,
  },
  {
    path: 'createuser',
    component: CreateNewUserComponent,
  },
  {
    path: 'role',
    component: RolesComponent,
  },
  {
    path: 'permission',
    component: PermissionComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SuperAdminRoutingModule {}
