import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ConfirmWindowComponent } from './components/confirm-window/confirm-window.component';
import { QuillModule } from 'ngx-quill';
import { ParseCodePipe } from './components/customPipe/parse-code.pipe';
import { CommentsComponent } from './components/comments/comments.component'

@NgModule({
  declarations: [ConfirmWindowComponent, ParseCodePipe, CommentsComponent],
  imports: [CommonModule, RouterModule, QuillModule],
  exports: [ConfirmWindowComponent,ParseCodePipe,CommentsComponent],
})
export class SharedModule {}
