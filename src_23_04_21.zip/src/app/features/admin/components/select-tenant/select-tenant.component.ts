import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApprovalQueueModel } from 'src/app/core/models/approval-queue.model';
import { LoginResponse } from 'src/app/core/models/header-menu.model';
import { CreateTenantModel } from 'src/app/core/models/tenant.model';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { ApprovalQueueService } from '../../services/approval-queue.service';

@Component({
  selector: 'app-select-tenant',
  templateUrl: './select-tenant.component.html',
  styleUrls: ['./select-tenant.component.css'],
})
export class SelectTenantComponent implements OnInit {
  pageManagement: LoginResponse;
  userId: number;

  constructor(
    private approvalQueueService: ApprovalQueueService,
    private LoginService: LoginService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.pageManagement = this.approvalQueueService.getSelectTenant();
    this.userId = this.LoginService.userId;
  }

  onClickTenant() {
    this.approvalQueueService
      .getTenantByUserId(this.userId)
      .subscribe((tenantlist: CreateTenantModel[]) => {
        this.approvalQueueService.setTenant(
          this.pageManagement.artifactName,
          tenantlist
        );
        this.router.navigate(['selecttenantlist']);
      });
  }
}
