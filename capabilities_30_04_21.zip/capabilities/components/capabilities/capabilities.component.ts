import { Component, OnInit, ViewChild, OnChanges } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder, FormsModule, Validators } from '@angular/forms';
import { MenuService } from 'src/app/core/services/menu/menu.service';
import { LoginService } from 'src/app/features/auth/services/login/login.service';
import { capabilitiesData,imageValue } from '../capabilities/capabilities.model';
import { TabDirective, TabsetComponent } from "ngx-bootstrap/tabs";
import { Subject } from 'rxjs';
import { CapabilitiesService } from './capabilities.service';
import { takeUntil } from 'rxjs/operators';
import { Route, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastNotificationService } from 'src/app/core/services/toast-notification/toast-notification.service';

@Component({
  selector: 'app-capabilities',
  templateUrl: './capabilities.component.html',
  styleUrls: ['./capabilities.component.css'],
})
export class CapabilitiesComponent implements OnInit {
  @ViewChild("tabset") tabset: TabsetComponent;
  @ViewChild("resourcesTab") resourcesTab;
  @ViewChild("technicalSummaryTab") technicalSummaryTab;
  @ViewChild("updatesTab") updatesTab;


  titleForm:FormGroup;

  options= [
               { label: "HTML", value: "html" },
               { label: "JS", value: "js" }
             ]
 myobj1 = capabilitiesData.examplesDTO[0].previews[0];
 myobj11 = capabilitiesData.examplesDTO[0].richTextBlock[0];
 myobj2= capabilitiesData.resourcesDTO[0];
 myObj3 = capabilitiesData.updatesDTO[0];
 headings=[];
 tabHeading: string = "Technical Summary";
 description="";
 pageTitle="";
 showForm:boolean=false;
 status="approved";
 private onDestroy$: Subject<void>;
  capabilitiesArray: any=[];
  draftList: any = [];
  approvedList:any=[];
  showHome: boolean = true;
  showCapability: boolean = false;
  tenantName: any;
 
  selectedCapabilityId=0;
  showExamplesAddBlock: boolean =true;
  showResourcesAddBlock: boolean=true;
  showUpdatesAddBlock: boolean=true;
  fileName: any='Select a file';

  constructor(public capabilityService:CapabilitiesService, private fb:FormBuilder,
    private toastNotificationService:ToastNotificationService, private route:Router) { 
    if (this.route.getCurrentNavigation().extras.queryParams != undefined) {
        this.tenantName = this.route.getCurrentNavigation().extras.queryParams.tenantName;

    }
    this.headings=[
    {tabTitle:"Technical Summary"},
    {tabTitle:"Resources"},
    {tabTitle:"Updates"}
  ]
  this.onDestroy$ = new Subject<void>();
  }

  cancel(){
    this.technicalSummaryTab.technicalSummaryForm.reset();
    this.resourcesTab.resourcesForm.reset();
    this.updatesTab.updatesForm.reset();
  }

  loadData(tab) {
   console.log("tab selected",tab)
    if (tab == "home") {
      this.showHome = true;
      this.showCapability = false;
      this.showForm = false;
    }
    else if (tab == "create") {
      this.showCapability = false;
      this.showHome = false;
      this.showForm = true;
    }
    else {
      if(this.status == 'approved'){
        this.selectedCapabilityId = tab.capabilitiesId;
        for(let i in this.approvedList){
          if(this.approvedList[i].pageTitle == tab.pageTitle){
            this.showCapability = true;
            this.showHome = false;
            this.showForm = false;
          }
          
        }
      
      }
      else{
        for(let i in this.approvedList){
        if(this.draftList[i].pageTitle == tab.pageTitle){
        this.showCapability = false;
        this.showHome = false;
        this.showForm = true;
      }
    }
    }
  }
  }

  confirmTabSwitch(data: TabDirective): void {
    this.tabHeading = data.heading;
    console.log(this.tabHeading);
  }

   ngOnInit(): void {
     this.titleForm= this.fb.group({
       pageTitle:["",[Validators.required,Validators.maxLength(80),Validators.pattern("^[a-zA-Z]+$")]],
       description:["",[Validators.required,Validators.maxLength(300),Validators.pattern("[a-zA-Z0-9_]+.*$")]]
     });
     this.getApprovedList();
     this.getDraftList();
    //this.approvedList =['Position Lists','Portfolios','Currency Allocation'];
    this.approvedList=[{
      status:"03",
      capabilitiesId:1,
      pageTitle:"Position Lists",
      description: "A button triggers an event or action. They let users know what will happen next.",
      userDetails: {
        userName:"test",
        tenantId:0
      },
    
      examplesDTO: [{
        previews:[{
        blockTitle: "Position List",
        summdescription: "Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        previewImages:[{
        previewImage:""
        }
        ],
        codeSection:[{
          syntax: "HTML",
          code: "body {↵  display: grid;↵  grid-template-rows: repeat(7, 1fr);↵  place-items: center;↵  overflow: hidden;↵}"
         },
         {
          syntax: "CSS",
          code: ".w-icon-slider-right:before {↵  content: "+"\e600"+";↵}↵.w-icon-slider-left:before {↵  content: "+"\e601"+";↵}↵.w-icon-nav-menu:before {↵  content: "+"\e602"+";↵}"
         }],
        }   
        ],
        richTextBlock:[{
          blockTitle: "Backend Services",
          richText:"Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        },
        {
          blockTitle: "Security Services",
          richText:"Components are the reusable building blocks of our design system. Each component meets a specific interaction or UI need, and has been specifically created to work together to create patterns and intuitive user experiences.",
        }]
      }],
      
      resourcesDTO: [
        {
        resourceName: "Invision Location",
        linkLocation: "invisionapp.com/4726bsHCY..."
        },
        {
          resourceName: "Sketch Location",
          linkLocation: "Toolkit / Misc / Buttons"
          },
          {
            resourceName: "Bitbucket",
            linkLocation: "bitbucket.org/cs-kit/38cnsas"
            }
      ],
      
      updatesDTO: [
        { 
        dateOfUpdate:"28 Jan 2020",
        version: "Version 70.2",
        updateDescription: "<ul><li>Use breadcrumbs when the user is most likely to have landed on the page from an external source.</li></ul>"}]
    },
    {
      status:"03",
      capabilitiesId:2,
      pageTitle:"Portfolios",
      description: "description",
      userDetails: {
        userName:"test",
        tenantId:0
      },
    
      examplesDTO: [{
        previews:[{
        blockTitle: "block title",
        summdescription: "summ description",
        previewImages:[{
        previewImage:"image path"
        }
        ],
        codeSection:[{
          syntax: "CSS",
          code: "code"
         },
         {
          syntax: "CSS",
          code: "code"
         }],
        }   
        ],
        richTextBlock:[{
          blockTitle: "block titkle",
          richText:"<ul><li>Use breadcrumbs when the user is most likely to have landed on the page from an external source.</li></ul>",
        }]
      }],
      
      resourcesDTO: [
        {
        resourceName: "resName",
        linkLocation: "lonklocation"
        }
      ],
      
      updatesDTO: [
        { 
        dateOfUpdate:"date",
        version: "version",
        updateDescription: "update desc"}]
    },{
      status:"03",
      capabilitiesId:3,
      pageTitle:"Currency Allocation",
      description: "description",
      userDetails: {
        userName:"test",
        tenantId:0
      },
    
      examplesDTO: [{
        previews:[{
        blockTitle: "block title",
        summdescription: "summ description",
        previewImages:[{
        previewImage:"image path"
        }
        ],
        codeSection:[{
          syntax: "CSS",
          code: "code"
         },
         {
          syntax: "CSS",
          code: "code"
         }],
        }   
        ],
        richTextBlock:[{
          blockTitle: "block titkle",
          richText:"richtext",
        }]
      }],
      
      resourcesDTO: [
        {
        resourceName: "resName",
        linkLocation: "lonklocation"
        }
      ],
      
      updatesDTO: [
        { 
        dateOfUpdate:"date",
        version: "version",
        updateDescription: "update desc"}]
    }];

   // this.draftList =['Documents','Performance Graph']
   this.draftList=[
     {
    status:"01",
    capabilitiesId:4,
    pageTitle:"Documents",
    description: "description",
    userDetails: {
      userName:"test",
      tenantId:0
    },
  
    examplesDTO: [{
      previews:[{
      blockTitle: "block title",
      summdescription: "summ description",
      previewImages:[{
      previewImage:"image path"
      }
      ],
      codeSection:[{
        syntax: "CSS",
        code: "code"
       },
       {
        syntax: "CSS",
        code: "code"
       }],
      }   
      ],
      richTextBlock:[{
        blockTitle: "block titkle",
        richText:"richtext",
      }]
    }],
    
    resourcesDTO: [
      {
      resourceName: "resName",
      linkLocation: "lonklocation"
      }
    ],
    
    updatesDTO: [
      { 
      dateOfUpdate:"date",
      version: "version",
      updateDescription: "update desc"}]
  },{
    status:"01",
    capabilitiesId:5,
    pageTitle:"Performance Graph",
    description: "description",
    userDetails: {
      userName:"test",
      tenantId:0
    },
  
    examplesDTO: [{
      previews:[{
      blockTitle: "block title",
      summdescription: "summ description",
      previewImages:[{
      previewImage:"image path"
      }
      ],
      codeSection:[{
        syntax: "CSS",
        code: "code"
       },
       {
        syntax: "CSS",
        code: "code"
       }],
      }   
      ],
      richTextBlock:[{
        blockTitle: "block titkle",
        richText:"richtext",
      }]
    }],
    
    resourcesDTO: [
      {
      resourceName: "resName",
      linkLocation: "lonklocation"
      }
    ],
    
    updatesDTO: [
      { 
      dateOfUpdate:"date",
      version: "version",
      updateDescription: "update desc"}]
  }];

    // this.forms = new FormGroup({
    //   previews: new FormArray([this.populatePreviewsArray()]),
    //   richTextBlock: new FormArray([this.populateRichTextArray()]),

    // });

    //  this.form2 = new FormGroup({
    //   resources: new FormArray([this.populateResourcesArray()]),
     

    // });
    //  this.form3 = new FormGroup({
    //    updates: new FormArray([this.populateUpdatesArray()]),

    // });
    // console.log(this.forms);
  }


  // convenience getter for easy access to form fields
  /**
   * @method titleFormControls
   * @return void
   */
  get titleFormControls() {
    return this.titleForm.controls;

  }
 
populateResourcesArray(): FormGroup{
   return new FormGroup({
      resourceName: new FormControl(""),
      linkLocation: new FormControl(""),
     });
}

  // get examples() {
  //   return (this.forms.get("previews") as FormArray).controls;
  // }
 
  // resource(): FormArray {
  //   return this.form2.get("resources") as FormArray
  // }
  



 
 
 
  closeResourcesAddBlock() {
    this.showResourcesAddBlock=false;
    }
 
  onStatusChange(event){
    this.status=event.target.value;
    if(this.status =='draft'){
      console.log("coming form changes");
      // this.forms = new FormGroup({
      //   previews: new FormArray([]),
      //   richTextBlock: new FormArray([this.populateRichTextArray()]),
  
      // });
  
      //  this.form2 = new FormGroup({
      //   resources: new FormArray([this.populateResourcesArray()]),
       
  
      // });
      //  this.form3 = new FormGroup({
      //    updates: new FormArray([this.populateUpdatesArray()]),
  
      // });
    }
    this.technicalSummaryTab.setPreviews();
    this.technicalSummaryTab.setRichText();
  }
  getCapabilities() {
    let data=''
    this.capabilityService.getAllCapabilities(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.capabilitiesArray = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  getByID() {
    let data=''
    this.capabilityService.getCapabilityByID(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.capabilitiesArray = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  getApprovedList() {
    let data='03'
    this.capabilityService.getCapabilityByStatus(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.approvedList = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }
  getDraftList() {
    let data='01'
    this.capabilityService.getCapabilityByStatus(data)
      .pipe(takeUntil(this.onDestroy$))
      .subscribe(res => {
        if (res) {
          this.draftList = res;
        }

      },
        err => {
          setTimeout(() => {
            //this.messageDialogService.dialog('Error', err, 'dialog', 'warning');
          }, 1000);
        });

  }

  makerAction(btnAction){

let model = {
  status:"01",
  capabilityId:0,
  pagetitle: {
    label: "Page Title",
    value: this.pageTitle,
    type: "text"
  },
  description: {
    label: "Description",
    value: this.description,
    type: "text"
  },
  userDetails: {
    userName:"test",
    tenantId:this.capabilityService.getSelectedMenuItem().tenantId
  },
  comments:{
    userName:"test",
    comment:"",
    inptDttm:""
  },

  examplesDTO: [],
  resourcesDTO: [],
  updatesDTO: []

};
 
  model['examplesDTO'] = [this.technicalSummaryTab.examplesFormToModel()];
  model['resourcesDTO'] = [this.resourcesTab.resourcesFormToModel()];
  model['updatesDTO'] = [this.updatesTab.updatesFormToModel()];
  if(btnAction == 'save'){
    model.status ="01"
  }
  else if(btnAction == 'submit'){
    model.status ="02"
  }

  // this.subscriptions.push(
    this.capabilityService.makerAction(model).subscribe(
      res => {
        this.toastNotificationService.showSuccess(
        btnAction == "save"?'Data saved as draft':'Capability submitted for approval'
        );
        this.route.navigate(['/CSDigital']);
      },
      (error: HttpErrorResponse) => {
        throw new Error(error.error.message);
      }
    )
  //);

  console.log("my model",model);
  }


  // resourcesFormToModel() {
  //   let modelData = Object.assign({}, capabilitiesData.resourcesDTO[0]);
  //   let formData = this.form2.getRawValue();
  //     for (let key in formData) {
  //     if (modelData.hasOwnProperty(key))
  //       modelData[key] = formData[key] || '';
  //   };
  //  console.log("modelData",modelData);
  //   return modelData;
  // };

  
 

  onSubmit() {
  
    //  console.log(this.form2.getRawValue());
     // console.log(this.form3.getRawValue());
      this.makerAction('submit');
      let arr = imageValue.split('_');
      console.log(arr[0],"fileName");
      console.log(arr[1]);
  }

  public ngOnDestroy(): void {
    this.onDestroy$.next();
    this.onDestroy$.complete();

  }
  
}
