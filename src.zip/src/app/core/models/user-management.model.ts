export class UserManagementModel {
  userId: number;
  email: string;
  name: string;
  tenantUser: UserManagementTenantModel[];
}

export class UserManagementTenantModel {
  tenantId?: number;
  tenantName?: string;
  roleName: string;
  roleId: number;
  artifactCategory?: string;
  tenantDescription?: string;
}
