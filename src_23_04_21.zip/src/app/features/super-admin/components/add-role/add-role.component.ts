import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { PermissionModel } from 'src/app/core/models/permission.model';
import { RoleModel, RolePermission } from 'src/app/core/models/roles.model';
import { PermissionService } from '../../services/permissoin/permission.service';
import { RoleService } from '../../services/role/role.service';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css'],
})
export class AddRoleComponent implements OnInit {
  @ViewChild('template', { static: true })
  templateref: TemplateRef<RoleModel>;
  @Output()
  rolePermissionDataFromChild: EventEmitter<RoleModel> = new EventEmitter();
  roleForm: FormGroup;
  modalRef: BsModalRef;
  permissionData: PermissionModel[];
  isEditMode: boolean;
  selectedRoleValue: RolePermission[] = [];
  isLoad: boolean;

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private roleService: RoleService,
    private permissionService: PermissionService
  ) {}

  ngOnInit() {
    this.isLoad = false;
  }

  get permission(): FormArray {
    return this.roleForm.get('permission') as FormArray;
  }

  public openModal(): void {
    this.getPermissionData();
    this.isEditMode = true;
    this.modalRef = this.modalService.show(this.templateref);
    console.log(this.roleForm);
  }

  public onSavePermissions(): void {
    const rolePermission: any[] = this.selectedRoleValue;
    const newData = { ...this.roleForm.value, rolePermission };
    this.roleService.addRole(newData).subscribe((data: RoleModel) => {
      this.modalRef.hide();
      this.roleForm.reset();
      this.rolePermissionDataFromChild.emit();
      this.selectedRoleValue = [];
    });
  }

  public onClose(): void {
    this.modalRef.hide();
    this.roleForm.reset();
  }

  public openRoleModalEdit(role: RoleModel): void {
    this.getPermissionData(role);
    this.isEditMode = false;
    if (role.rolePermission) {
      this.selectedRoleValue = role.rolePermission;
    }
    this.modalRef = this.modalService.show(this.templateref);
  }

  private setExistingPermissoins(): void {
    if (this.selectedRoleValue) {
      this.permissionData.forEach((value) => {
        const indexvalue = this.selectedRoleValue.findIndex(
          (item) => item.permissionId === value.permissionId
        );
        if (indexvalue !== -1) {
          this.permission.push(this.fb.control(true));
        } else {
          this.permission.push(this.fb.control(false));
        }
      });
    }
  }

  public onUpdateRole(): void {
    const rolePermission: any[] = this.selectedRoleValue;
    const newData = { ...this.roleForm.value, rolePermission };
    this.roleService.updateRole(newData.roleId, newData).subscribe((data) => {
      if (data) {
        this.modalRef.hide();
        this.roleForm.reset();
        this.rolePermissionDataFromChild.emit();
        this.selectedRoleValue = [];
      }
    });
  }

  public onRoleCheckbox(event, roleIndex): void {
    const valueData = event.target.value;
    if (event.target.checked) {
      this.selectedRoleValue.push({
        permissionId: this.permissionData[roleIndex].permissionId,
        permissionName: this.permissionData[roleIndex].permissionName,
      });
    } else {
      const getIndex = this.selectedRoleValue.findIndex(
        (t: RolePermission) => t.permissionName === valueData
      );
      this.selectedRoleValue.splice(getIndex, 1);
    }
  }

  private populatePermission(): FormControl[] {
    const control = this.setControlsCustom();
    return control;
  }

  private setControlsCustom(): FormControl[] {
    return this.permissionData.map((item: PermissionModel) => {
      return this.fb.control(false);
    });
  }

  private getPermissionData(role?): void {
    this.permissionService.getPermission().subscribe(
      (data: PermissionModel[]) => {
        this.permissionData = data;
        this.createRoleForm();
        if (this.isEditMode) {
          const test = this.populatePermission();
          test.forEach((item) => {
            this.permission.push(item);
          });
          this.isLoad = true;
        } else {
          this.setExistingPermissoins();
          this.roleForm.patchValue(role);
          this.isLoad = true;
        }
      },
      (error) => {
        throw new Error(error.error.message);
      }
    );
  }

  private createRoleForm(): void {
    this.roleForm = this.fb.group({
      roleId: '',
      roleName: '',
      roleDescription: '',
      permission: this.fb.array([]),
    });
  }
}
