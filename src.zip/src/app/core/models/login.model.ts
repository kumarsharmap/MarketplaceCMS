export class CreateLoginRequest {
  email: string;
  password: string;
  rememeberme?: boolean;
}
