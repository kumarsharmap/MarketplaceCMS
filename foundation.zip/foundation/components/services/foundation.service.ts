import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class FoundationService {

  constructor(private http: HttpClient) { }

  colorFormSubmit(data) {
    return this.http.post(environment.apiEndpoint + "/foundation/colour", data);
  }
  getAllFoundations() {
    return this.http.get(environment.apiEndpoint + "/foundation/colour");
  }
  fetchDetailsById(id) {
    return this.http.get(environment.apiEndpoint + "/foundation", id);
  }
}
