import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FoundationService {
  userDetails: any;
  setApprovalHeaderData(data: any) {
    this.userDetails = data;
  };

  getApprovalHeaderData() {
    return this.userDetails.tenantId;
  };
  constructor(private http: HttpClient) { }

  colorFormSubmit(data) {
    return this.http.post("foundation/colour", data);
  }
  getAllFoundations() {
    return this.http.get("foundation/colour");
  }
  fetchDetailsById(id) {
    return this.http.get("foundation", id);
  }
  getArtifactsByStatus(status) {
    return this.http.get("foundation" + status);
  }
  othersFoundationFormSubmit(data) {
    return this.http.post("foundation/others", data);
  }
}
