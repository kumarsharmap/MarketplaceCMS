import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import(`./features/auth/auth.module`).then((m) => m.AuthModule),
  },
  {
    path: 'landing',
    loadChildren: () =>
      import(`./features/landing/landing.module`).then((m) => m.LandingModule),
  },
  {
    path: 'createTenantList',
    loadChildren: () =>
      import(`./features/super-admin/super-admin.module`).then(
        (m) => m.SuperAdminModule
      ),
  },
  {
    path: 'approval',
    loadChildren: () =>
      import(`./features/admin/admin.module`).then((m) => m.AdminModule),
  },
  {
    path: 'CSDigital',
    loadChildren: () =>
      import(`./features/capabilities/capabilities.module`).then(
        (m) => m.CapabilitiesModule
      ),
  },
  { path: '', redirectTo: '', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
