import { Component, OnInit } from '@angular/core';
import { CapabilitiesService } from '../capabilities/capabilities.service';

@Component({
  selector: 'app-capabilities-home',
  templateUrl: './capabilities-home.component.html',
  styleUrls: ['./capabilities-home.component.css']
})
export class CapabilitiesHomeComponent implements OnInit {

  constructor(public capabilityService:CapabilitiesService) { }

  ngOnInit(): void {
  }

}
