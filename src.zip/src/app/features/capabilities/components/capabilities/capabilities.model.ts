export const capabilitiesData = {
    pagetitle: {
      label: "Page Title",
      value: "Position List",
      type: "text"
    },
    description: {
      label: "Description",
      value: "some description",
      type: "text"
    },
    userDetails: {
      userName:"test",
      artifactId:"test"
    },
  
    examplesDTO: [{
      previews:[{
        blockTitle: {
        controlName: "blockTitle",
        label: "Block Title",
        value: "Position List",
        type: "text"
      },
      summdescription: {
        controlName: "summdescription",
        label: "Descriptuion",
        value: "some description",
        type: "text"
      },
      previewImages:[{
      previewImage:{
        controlName: "previewImage",
        label: "Upload Preview Image",
        value: "Select a file",
        type: "file"
         }
      }
      ],
      codeSection:[{
        syntax: {
        controlName: "syntax",
        label: "Syntax",
        value: "js",
        type: "select",
        options: [
          { label: "HTML", value: "html" },
          { label: "JS", value: "js" },
          { label: "Angular", value: "angular" },
        ]
      },
      code: {
        controlName: "code",
        label: "Code",
        value: "",
        type: "text"
      }
       }],
      }   
      ],
      richTextBlock:[{
        blockTitle: {
        controlName: "blockTitle",
        label: "Block Title",
        value: "Backend Services",
        type: "text"
      },
        richText: {
        controlName: "richText",
        label: "Rich Text",
        value: "Some Rich Text",
        type: "text"
      },
      }]
    }],
    
    resourcesDTO: [
      {
      resourceName: {
        controlName: "resourceName",
        label: "Resource Name",
        value: "js",
        type: "select",
        options: [
          { label: "HTML", value: "html" },
          { label: "JS", value: "js" }
        ]
      },
      linkLocation: {
        controlName: "linkLocation",
        label: "Link or Localtion",
        value: "some descriptiom",
        type: "text"
      }
      }
    ],
    
    updatesDTO: [
      { 
        dateOfUpdate: {
        controlName: "dateOfUpdate",
        label: "Date Of Update",
        value: "21/06/2020",
        type: "text"
      },
      version: {
        controlName: "version",
        label: "Version",
        value: "some descriptiom",
        type: "text"
      },
      updateDescription: {
        controlName: "updateDescription",
        label: "Description",
        value: "some descriptiom",
        type: "text"
      }}]
  };