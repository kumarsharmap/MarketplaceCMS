export class HttpClientHelper {
  static PERMISSION = 'permissions';
  static ROLE = 'roles';
  static LOGIN = 'login';
  static REGISTER = 'user';
  static PROJECTS = 'tenantList';
  static ADDUSER = 'addUser';
  static TENANT = 'tenant';
  static TENANTSByADMIN = 'tenantsByAdmin';
  static ARTIFACT = 'artifact';
  static USERMANAGEMENT = 'user';
  static CHANGEPASSWORD = 'changepassword';
  static FORGOT = 'forgotpassword';
  static APPROVALQUEUE = 'approvalQueue';
  static PAGEMANAGEMENT = 'pageManagement';
}
