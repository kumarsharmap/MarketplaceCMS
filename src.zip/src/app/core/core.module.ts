import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHandler, ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { HeaderAdminComponent } from './components/header-admin/header-admin.component';
import { HeaderComponent } from './components/header/header.component';
import { CoreRoutingModule } from './core-routing.module';
import { NavigationDropdownDirective } from './directives/drop-down/navigation-dropdown.directive';
import { HasRoleDirective } from './directives/has-role/has-role.directive';
import { ServerErrorInterceptor } from './interceptors/server-error.interceptor';
import { GlobalErrorHandlerService } from './services/global-error-handler/global-error-handler.service';
import { MenuService } from './services/menu/menu.service';

@NgModule({
  declarations: [
    HeaderAdminComponent,
    HeaderComponent,
    NavigationDropdownDirective,
    HasRoleDirective,
  ],
  imports: [
    CommonModule,
    RouterModule,
    CoreRoutingModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-center',
      preventDuplicates: true,
    }),
  ],
  exports: [
    HeaderAdminComponent,
    HeaderComponent,
    NavigationDropdownDirective,
    HasRoleDirective,
  ],
  providers: [
    { provide: ErrorHandler, useClass: GlobalErrorHandlerService },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ServerErrorInterceptor,
      multi: true,
    },
  ],
})
export class CoreModule {
  static forRoot(): ModuleWithProviders<CoreModule> {
    return {
      ngModule: CoreModule,
      providers: [MenuService],
    };
  }
}
